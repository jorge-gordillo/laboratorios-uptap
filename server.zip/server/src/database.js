import { Sequelize } from "sequelize"
import { DB_URI, NODE_ENV, DIALECT } from './config'

const URI = DB_URI[NODE_ENV]

export const sequelize = new Sequelize(
	URI,
	{
		dialect: DIALECT,
		logging: false,
		pool: {
			max: 5,
			min: 0,
			require: 30000,
			idle: 10000
		}
	}
)

export const dbConnect = async () => {
	try {
		await sequelize.authenticate()
		console.log(`${DIALECT} conneted in ${NODE_ENV} enviroment`)
	} catch (error) {
		console.error(`${DIALECT} Error conneted ${error.message}`)
	}
}