import '@babel/polyfill'
import { PORT, HOSTNAME } from "./config";
import app from './app'
import { dbConnect } from './database'

const main = async () => {
   try {
      await app.listen(PORT)
      console.log(`Server listen on http://${HOSTNAME}/`);
   } catch (error) {
      console.error('Server Error: ' + error.message);
   }
}

main()
dbConnect()