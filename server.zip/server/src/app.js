import "@babel/polyfill"
import express, { json, urlencoded } from "express"
import cors from 'cors'
import logger from 'morgan'
import bodyParser from "body-parser"
import appRouter from './routes'

const app = express()

// Middlewares
app.use(cors())
app.use(bodyParser.json())
app.use(logger('dev'))
app.use(json())
app.use(urlencoded({ extended: true}))

// Rutas
app.use('/api', appRouter)

// Rutas publicas
app.use('/', express.static(`${__dirname}/documentation/`))
app.use('/public', express.static(`${__dirname}/public/`))

export default app