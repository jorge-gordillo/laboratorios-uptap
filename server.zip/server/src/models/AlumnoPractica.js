import { DataTypes } from "sequelize"
import { sequelize } from "../database"

const AlumnoPractica = sequelize.define('alumno_practica', {
   
}, {
   timestamps: false,
   underscored: false,
   tableName: 'alumno_practica'
})

export default AlumnoPractica