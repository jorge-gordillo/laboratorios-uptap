descripcionComputo: {
   numSerieMonitor: 1,
   numSerieCpu: 1,
   numSerieMouse: 1,
   numSerieTeclado: 1,
}

descripcionRedes: {
   numSerie: 1,
}