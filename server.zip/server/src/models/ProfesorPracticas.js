import { DataTypes } from "sequelize"
import { sequelize } from "../database"

const ProfesorPracticas = sequelize.define('profesor_practicas', {
   idProfesorPracticas: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
   },
   entrada: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: new Date()
   },
   salida: {
      type: DataTypes.DATE,
      allowNull: true
   },
   idHorario: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
         key: 'idHorario',
         model: 'horarios'
      }
   }
}, {
   timestamps: false,
   underscored: true,
   tableName: 'ingreso_profesor'
})

export default ProfesorPracticas