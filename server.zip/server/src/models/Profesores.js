import { DataTypes } from "sequelize"
import { sequelize } from "../database"


const Profesores = sequelize.define('profesores', {
	idProfesor: {
		type: DataTypes.INTEGER,
		autoIncrement: true,
		primaryKey: true,
		allowNull: false
	},
	nombre: {
		type: DataTypes.STRING(45),
		allowNull: false
	}
}, {
   timestamps: false,
	underscored: true,
	tableName: 'profesores'
})

export default Profesores