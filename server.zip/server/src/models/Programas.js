import { DataTypes } from "sequelize";
import { sequelize } from '../database'

const Programas = sequelize.define('programas', {
   idProgramas: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false 
   },
   nombre: {
      type: DataTypes.TEXT('tiny'),
      allowNull: false
   },
   version: {
      type: DataTypes.TEXT('tiny'),
      allowNull: false
   }
}, {
   timestamps: false,
	underscored: true,
	tableName: 'programas'
})

export default Programas