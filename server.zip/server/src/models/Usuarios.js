import { DataTypes } from "sequelize";
import { sequelize } from '../database'

const Usuarios =  sequelize.define('usuarios', {
   uid: {
      type: DataTypes.UUID,
      primaryKey: true,
      allowNull: false,
      defaultValue: DataTypes.UUIDV4
   },
   email: {
      type: DataTypes.TEXT('tiny'),
      unique: true,
      allowNull: false,
      validate: {
         isEmail: true,
         notEmpty: true,
         notNull: true
      }
   },
   password: {
      type: DataTypes.TEXT('tiny'),
      allowNull: false,
      validate: {
         notEmpty: true,
         notNull: true,
         isUUID: true
      }
   },
   status: {
      type: DataTypes.STRING(10),
      allowNull: false,
		defaultValue: 'invited',
		values: [ 'invited', 'active', 'inactive', 'blocked' ],
		validate: {
			notEmpty: true
		}
   }
}, {
   timestamps: true,
	underscored: true,
	tableName: 'usuarios'
})

export default Usuarios
