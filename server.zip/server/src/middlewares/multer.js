import multer, { diskStorage } from 'multer'

export const uploadImg = multer({
   storage: diskStorage({
      destination: function (req, file, cb) {
         const pathStorage = `${__dirname}/../public/img/`
         cb(null, pathStorage)
      },
      filename: function (req, file, cb) {
         const ext = file.originalname.split('.').pop()
         const fileName = `${req.tokenUid}.${ext}`
         cb(null, fileName)
      }
   })
})

export const uploadDoc = multer({
   storage: diskStorage({
      destination: function (req, file, cb) {
         const pathStorage = `${__dirname}/../public/doc/`
         cb(null, pathStorage)
      },
      filename: function (req, file, cb) {
         const ext = file.originalname.split('.').pop()
         const fileName = `${req.tokenUid}.${ext}`
         cb(null, fileName)
      }
   })
})