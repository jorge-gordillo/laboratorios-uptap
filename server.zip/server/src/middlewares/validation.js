import User from "../models/User"
import { httpError } from "../helpers"

export const isRegular = (req, res, next) => {
	const role = req.tokenRole
	try {
		if (role !== 'regular') {
			return httpError(res, 403, 'No autorizado! Se requiere role Regular')
		}
		next()
	} catch (e) {
		return httpError(res, 500, 'Error interno del servidor', '/middleware/validation/isRegular', e.message)
	}
}
export const isCompany = (req, res, next) => {
	const role = req.tokenRole
	try {
		if (role !== 'company') {
			return httpError(res, 403, 'No autorizado! Se requiere role Company')
		}
		next()
	} catch (e) {
		return httpError(res, 500, 'Error interno del servidor', '/middleware/validation/isCompany', e.message)
	}
}
export const isAdmin = (req, res, next) => {
   const role = req.tokenRole
	try {
		if (role !== 'admin') {
			return httpError(res, 403, 'No autorizado! Se requiere role Admin')
		}
		next()
	} catch (e) {
		return httpError(res, 500, 'Error interno del servidor', '/middleware/validation/isAdmin', e.message)
	}
}

export const checkDuplicateEmail = async (req, res, next) => {
	const email = req.body.email
	try {
		const userFound = await User.findOne(
			{ where: { email }}
		)
		if (userFound) {
			return httpError(res, 400, '¡Ha fallado! El email ya esta en uso')
		}
		next()
	} catch (e) {
		return httpError(res, 500, 'Error interno del servidor', '/middleware/validation/checkDuplicateEmail', e.message)
	}
}