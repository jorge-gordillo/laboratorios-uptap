import jwt, { TokenExpiredError } from 'jsonwebtoken'
import { serverError, errorResponse } from "../helpers";

const JWT_SECRET = process.env.JWT_SECRET

export const verifyToken = async (req, res, next) => {
   const token = req.headers['x-access-token'] || req.body.token || req.params.token || null
   try {
      if (!token) return errorResponse({ res, msg: 'Usuario no autenticado' })

      jwt.verify(token, JWT_SECRET, (err, decoded) => {
         if (err) {
            if (err instanceof TokenExpiredError) {
               return errorResponse({ res, status: 403, msg: 'No autorizado! El token ha expirado' })
            } else {
               return errorResponse({ res, status: 400, msg: 'Error! El token es invalido' })
            }
         }
         req.tokenUid = decoded.uid
         req.tokenRole = decoded.role
         next()
      })
   } catch (error) {
      serverError({ res, from: 'authorization/verifyToken', error })
   }
}