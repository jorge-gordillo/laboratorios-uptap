export const dataResponse = ({ res, status = 200, msg = 'OK', data = null }) => {
   res.status(status).json({
      msg,
      data
   })
}