export const serverError = ({ res, msg = 'Error interno del servidor', status = 500, error, from = null }) => {
   console.log({ status: 'Error', from, msg: error.message, error })
   res.status(status).json({
      error: {
         status,
         msg
      }
   })
}
 
export const errorResponse = ({ res, msg = "Algo ocurrio", status = 400 }) => {
   res.status(status).json({
      error: {
         status,
         msg
      }
   })   
}