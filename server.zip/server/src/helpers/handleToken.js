import jwt from 'jsonwebtoken'
const JWT_SECRET = process.env.JWT_SECRET || 'jsonwebtokensecret'
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || 3600000
const REFRESH_SECRET = process.env.REFRESH_SECRET || 'refreshjsonwebtokensecret'
const REFRESH_EXPIRES_IN = process.env.REFRESH_EXPIRES_IN || 86400000

export const tokenSign = async ({ uid, role }) => {
	return await jwt.sign(
		{ uid, role },
		JWT_SECRET,
		{ expiresIn: JWT_EXPIRES_IN }
	)
}

export const verifyToken = async (token) => {
	await jwt.verify(token, JWT_SECRET, (err, decode) => {
		return { err, decode }
	})
}

export const decodeToken = (token) => {
	return jwt.decode(token, null)
}

export const refreshSign = async ({ uid, role}) => {
	return await jwt.sign(
		{ uid, role },
		REFRESH_SECRET,
		{ expiresIn: REFRESH_EXPIRES_IN }
	)
}

export const verifyRegresh = async (token) => {
	jwt.verify(token, REFRESH_SECRET, (error, decode) => {
		return { error, decode }
	})
}