import ip from 'ip'
import dotenv from 'dotenv'
dotenv.config()

const NODE_ENV = process.env.NODE_ENV || 'development'
const DIALECT = process.env.DIALECT || 'postgres'
const PORT = process.env.PORT || 3000
const HOSTNAME = (NODE_ENV === 'production' ? process.env.HOSTNAME : ip.address()) + `:${PORT}`

const DB_URI = {
   development:  process.env.DB_URI_DEV,
   test: process.env.DB_URI_TEST,
   production: process.env.DB_URI
}

export {
   NODE_ENV,
   DIALECT,
   PORT,
   HOSTNAME,
   DB_URI
}