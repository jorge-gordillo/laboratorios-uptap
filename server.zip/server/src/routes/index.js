import { Router } from "express"
import usuariosRouter from '../api/admin/AdminRouter'

const appRouter = Router()

appRouter.use('/v1/admin', usuariosRouter)

export default appRouter