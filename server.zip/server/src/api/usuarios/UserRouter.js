import { Router } from "express"
import { verifyToken } from '../../middlewares'
import { login, changePassword, resetPassword, newPassword, deactivateAccount } from "./UsersController"

const router = Router()

router.post('/login', login)

router.put('/password',
   [verifyToken],
   changePassword
)

router.post('/reset-password', resetPassword)

router.put('/new-password', newPassword)

router.put('/account',
   [verifyToken],
   deactivateAccount
)

export default router
