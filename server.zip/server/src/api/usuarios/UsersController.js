import { tokenSign, refreshSign, serverError, errorResponse, comparePassword, encryptPassword, dataResponse } from '../../helpers'
import { HOSTNAME } from '../../config'
import { loginDto } from './UserDto'
import { User } from "../../models"

export const login = async (req, res) => {
	const { email, password } = req.body
	try {
		if (!email || !password) return errorResponse({res, msg: 'Correo o contraseña no proporcionados'})

      const userFound = await User.findOne(
			{ where: { email } }
		)

		const matchPassword = await comparePassword(password, userFound?.password || '')

		if (!userFound || !matchPassword) return errorResponse({ res, msg: 'Correo o contraseña incorrectos!' })
		if (userFound?.status === 'blocked') return errorResponse({ res, status: 403, msg: 'Has sido bloqueado por el administrador' })
		
		const token = await tokenSign(userFound)
		const refreshToken = await refreshSign(userFound)

		dataResponse({ res, status: 201, data: loginDto(userFound, { token, refreshToken })})
	} catch (error) {
		serverError({ res, error, from: 'UserController/login' })
	}
}

export const changePassword = async (req, res) => {
	const uid = req.tokenUid
	const { password, newPassword } = req.body
	try {
		const userFoud = await User.findByPk(uid,
			{ attributes: ['password'] }
		)

		const matchPassword = await comparePassword(password, userFoud.password)
		if (!matchPassword) return errorResponse({ res, msg: 'Contraseña actual incorrecta' })
		
		const newPAsswordEncript = await encryptPassword(newPassword)

		await User.update(
			{ password: newPAsswordEncript },
         { where: { uid }}
		)
		dataResponse({ res, msg: 'Contraseña actualizada correctamente'})
	} catch (error) {
		serverError({ res, error, from: 'UsersController/changedPassword'})
   }
}

export const resetPassword = async (req, res) => {
	res.json({
		data: {
			msg: "Correo de recuperacion de contraseña enviado"
		}
	})
}

export const newPassword = async (req, res) => {
	res.json({
		data: {
			msg: "Nueva contraseña creada correctamente"
		}
	})
}

export const deactivateAccount = async (req, res) => {
	const uid = req.tokenUid
	const status = 'inactive'
	try {
		await User.update({ status }, { where: { uid } })
		dataResponse({ res, msg: 'OK', data: { msg: 'Usuario actualizado correctamente' }})
	} catch (error) {
		serverError({ res, error, from: 'UsersController/deactivateAccount'})
	}
}