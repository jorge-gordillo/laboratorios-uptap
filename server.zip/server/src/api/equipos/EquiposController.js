

const getEquipos = async () => {

}

const getEquipoById = async () => {
   
}

const getEquipoByIdProgramas = async () => {
   
}