from .base import *

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False
ALLOWED_HOSTS = ['*']

CORS_ALLOWED_ORIGINS = [""]

CORS_ALLOWED_ORIGIN_REGEXES = [
    r"^https://\w+\.127.0.0.1",
    r"^https://\w+\.192.168.0.254",
    r"^https://labs-uptap.web.app",
    r"^https://labs-uptap.firebaseapp.com",
]

# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',  # Libreria para PostgreSQL
        'NAME': 'laboratorios',  # Nombre de la base de datos PostgreSQL
        'USER': 'postgres',  # Usuario de la base de datos PostgreSQL
        'PASSWORD': 'jorge503',  # Contraseña de usuario PostgreSQL
        'HOST': 'localhost',  # Ubicacion de la base de datos
        'DATABASE_PORT': '5432',  # Puerto utilizado
    }
}
