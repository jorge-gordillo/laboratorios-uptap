from .base import *

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True
ALLOWED_HOSTS = [
    "labs-uptap.web.app",
    "labs-uptap.firebaseapp.com",
    "192.168.182.180",
    "127.0.0.1",
    "192.168.207.180",
    "laboratorios-uptap.herokuapp.com"
]

CORS_ALLOWED_ORIGINS = [
    "https://labs-uptap.web.app",
    "https://labs-uptap.firebaseapp.com",
    "http://192.168.182.180",
    "http://192.168.207.180",
]

CORS_ALLOWED_ORIGIN_REGEXES = [
    "labs-uptap.web.app",
    "labs-uptap.firebaseapp.com",
    "192.168.182.180",
    "192.168.207.180",
]


# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',  # Libreria para PostgreSQL
        'NAME': 'laboratorios',  # Nombre de la base de datos PostgreSQL
        'USER': 'postgres',  # Usuario de la base de datos PostgreSQL
        'PASSWORD': 'jorge503',  # Contraseña de usuario PostgreSQL
        'HOST': 'localhost',  # Ubicacion de la base de datos
        'DATABASE_PORT': '5432',  # Puerto utilizado
    }
}
