--
-- PostgreSQL database dump
--

-- Dumped from database version 10.20
-- Dumped by pg_dump version 10.20

-- Started on 2022-05-27 12:56:53

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 1 (class 3079 OID 12924)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 3460 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 228 (class 1259 OID 67929)
-- Name: SIIIP_ROLES_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIIP_ROLES_CAT" (
    id bigint NOT NULL,
    description character varying(20) NOT NULL
);


ALTER TABLE public."SIIIP_ROLES_CAT" OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 67927)
-- Name: SIIIP_ROLES_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIIP_ROLES_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIIP_ROLES_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3461 (class 0 OID 0)
-- Dependencies: 227
-- Name: SIIIP_ROLES_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIIP_ROLES_CAT_id_seq" OWNED BY public."SIIIP_ROLES_CAT".id;


--
-- TOC entry 253 (class 1259 OID 68219)
-- Name: SIIUP_ALUMN_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_ALUMN_CAT" (
    enrollment integer NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(15) NOT NULL,
    second_last_name character varying(15) NOT NULL,
    gender character varying(50) NOT NULL,
    email character varying(254) NOT NULL
);


ALTER TABLE public."SIIUP_ALUMN_CAT" OWNER TO postgres;

--
-- TOC entry 257 (class 1259 OID 68236)
-- Name: SIIUP_ALUMN_ESC_DET; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_ALUMN_ESC_DET" (
    id bigint NOT NULL,
    other_procedence_school character varying(50) NOT NULL,
    highschool_area character varying(30) NOT NULL,
    average character varying(6) NOT NULL,
    location character varying(30) NOT NULL,
    date_admission date NOT NULL,
    date_egress date NOT NULL,
    enrollment_id integer NOT NULL,
    generation_id bigint NOT NULL,
    group_id bigint NOT NULL,
    period_id bigint NOT NULL,
    postgraduate_id bigint NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_ALUMN_ESC_DET" OWNER TO postgres;

--
-- TOC entry 256 (class 1259 OID 68234)
-- Name: SIIUP_ALUMN_ESC_DET_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_ALUMN_ESC_DET_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_ALUMN_ESC_DET_id_seq" OWNER TO postgres;

--
-- TOC entry 3462 (class 0 OID 0)
-- Dependencies: 256
-- Name: SIIUP_ALUMN_ESC_DET_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_ALUMN_ESC_DET_id_seq" OWNED BY public."SIIUP_ALUMN_ESC_DET".id;


--
-- TOC entry 216 (class 1259 OID 67865)
-- Name: SIIUP_CAREER_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_CAREER_CAT" (
    id bigint NOT NULL,
    academic_program_name character varying(60) NOT NULL,
    homosigla character varying(10) NOT NULL,
    academic_program_name_gdp character varying(70) NOT NULL,
    modality_id bigint NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_CAREER_CAT" OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 67863)
-- Name: SIIUP_CAREER_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_CAREER_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_CAREER_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3463 (class 0 OID 0)
-- Dependencies: 215
-- Name: SIIUP_CAREER_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_CAREER_CAT_id_seq" OWNED BY public."SIIUP_CAREER_CAT".id;


--
-- TOC entry 252 (class 1259 OID 68076)
-- Name: SIIUP_CAREER_SUBJECT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_CAREER_SUBJECT" (
    id bigint NOT NULL,
    career_id bigint NOT NULL,
    subject_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_CAREER_SUBJECT" OWNER TO postgres;

--
-- TOC entry 251 (class 1259 OID 68074)
-- Name: SIIUP_CAREER_SUBJECT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_CAREER_SUBJECT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_CAREER_SUBJECT_id_seq" OWNER TO postgres;

--
-- TOC entry 3464 (class 0 OID 0)
-- Dependencies: 251
-- Name: SIIUP_CAREER_SUBJECT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_CAREER_SUBJECT_id_seq" OWNED BY public."SIIUP_CAREER_SUBJECT".id;


--
-- TOC entry 218 (class 1259 OID 67879)
-- Name: SIIUP_CHARGE; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_CHARGE" (
    id bigint NOT NULL,
    charge character varying(20) NOT NULL,
    description character varying(100) NOT NULL
);


ALTER TABLE public."SIIUP_CHARGE" OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 67877)
-- Name: SIIUP_CHARGE_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_CHARGE_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_CHARGE_id_seq" OWNER TO postgres;

--
-- TOC entry 3465 (class 0 OID 0)
-- Dependencies: 217
-- Name: SIIUP_CHARGE_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_CHARGE_id_seq" OWNED BY public."SIIUP_CHARGE".id;


--
-- TOC entry 220 (class 1259 OID 67891)
-- Name: SIIUP_CYCLE_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_CYCLE_CAT" (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_CYCLE_CAT" OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 67889)
-- Name: SIIUP_CYCLE_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_CYCLE_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_CYCLE_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3466 (class 0 OID 0)
-- Dependencies: 219
-- Name: SIIUP_CYCLE_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_CYCLE_CAT_id_seq" OWNED BY public."SIIUP_CYCLE_CAT".id;


--
-- TOC entry 222 (class 1259 OID 67901)
-- Name: SIIUP_GENERATION_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_GENERATION_CAT" (
    id bigint NOT NULL,
    description character varying(30) NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_GENERATION_CAT" OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 67899)
-- Name: SIIUP_GENERATION_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_GENERATION_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_GENERATION_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3467 (class 0 OID 0)
-- Dependencies: 221
-- Name: SIIUP_GENERATION_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_GENERATION_CAT_id_seq" OWNED BY public."SIIUP_GENERATION_CAT".id;


--
-- TOC entry 224 (class 1259 OID 67911)
-- Name: SIIUP_GROUP_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_GROUP_CAT" (
    id bigint NOT NULL,
    "group" character varying(30) NOT NULL,
    availability integer NOT NULL,
    code character varying(32) NOT NULL,
    career_id bigint NOT NULL,
    generation_id bigint NOT NULL,
    group_type_id bigint NOT NULL,
    period_id bigint NOT NULL,
    quarter_id bigint NOT NULL,
    shift_id bigint NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_GROUP_CAT" OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 67909)
-- Name: SIIUP_GROUP_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_GROUP_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_GROUP_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3468 (class 0 OID 0)
-- Dependencies: 223
-- Name: SIIUP_GROUP_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_GROUP_CAT_id_seq" OWNED BY public."SIIUP_GROUP_CAT".id;


--
-- TOC entry 250 (class 1259 OID 68033)
-- Name: SIIUP_GROUP_SUBJECT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_GROUP_SUBJECT" (
    id bigint NOT NULL,
    group_id bigint NOT NULL,
    subject_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_GROUP_SUBJECT" OWNER TO postgres;

--
-- TOC entry 249 (class 1259 OID 68031)
-- Name: SIIUP_GROUP_SUBJECT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_GROUP_SUBJECT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_GROUP_SUBJECT_id_seq" OWNER TO postgres;

--
-- TOC entry 3469 (class 0 OID 0)
-- Dependencies: 249
-- Name: SIIUP_GROUP_SUBJECT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_GROUP_SUBJECT_id_seq" OWNED BY public."SIIUP_GROUP_SUBJECT".id;


--
-- TOC entry 248 (class 1259 OID 68023)
-- Name: SIIUP_GROUP_TYPE_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_GROUP_TYPE_CAT" (
    id bigint NOT NULL,
    description character varying(30) NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_GROUP_TYPE_CAT" OWNER TO postgres;

--
-- TOC entry 247 (class 1259 OID 68021)
-- Name: SIIUP_GROUP_TYPE_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_GROUP_TYPE_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_GROUP_TYPE_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3470 (class 0 OID 0)
-- Dependencies: 247
-- Name: SIIUP_GROUP_TYPE_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_GROUP_TYPE_CAT_id_seq" OWNED BY public."SIIUP_GROUP_TYPE_CAT".id;


--
-- TOC entry 246 (class 1259 OID 68013)
-- Name: SIIUP_MODALITY_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_MODALITY_CAT" (
    id bigint NOT NULL,
    description character varying(250) NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_MODALITY_CAT" OWNER TO postgres;

--
-- TOC entry 245 (class 1259 OID 68011)
-- Name: SIIUP_MODALITY_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_MODALITY_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_MODALITY_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3471 (class 0 OID 0)
-- Dependencies: 245
-- Name: SIIUP_MODALITY_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_MODALITY_CAT_id_seq" OWNED BY public."SIIUP_MODALITY_CAT".id;


--
-- TOC entry 244 (class 1259 OID 68005)
-- Name: SIIUP_PERIOD_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_PERIOD_CAT" (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    vacational_start_date date NOT NULL,
    vacational_end_date date NOT NULL,
    cycle_id bigint NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_PERIOD_CAT" OWNER TO postgres;

--
-- TOC entry 243 (class 1259 OID 68003)
-- Name: SIIUP_PERIOD_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_PERIOD_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_PERIOD_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3472 (class 0 OID 0)
-- Dependencies: 243
-- Name: SIIUP_PERIOD_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_PERIOD_CAT_id_seq" OWNED BY public."SIIUP_PERIOD_CAT".id;


--
-- TOC entry 242 (class 1259 OID 67995)
-- Name: SIIUP_QUALIFICATION_TYPE_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_QUALIFICATION_TYPE_CAT" (
    id bigint NOT NULL,
    description character varying(30) NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_QUALIFICATION_TYPE_CAT" OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 67993)
-- Name: SIIUP_QUALIFICATION_TYPE_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_QUALIFICATION_TYPE_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_QUALIFICATION_TYPE_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3473 (class 0 OID 0)
-- Dependencies: 241
-- Name: SIIUP_QUALIFICATION_TYPE_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_QUALIFICATION_TYPE_CAT_id_seq" OWNED BY public."SIIUP_QUALIFICATION_TYPE_CAT".id;


--
-- TOC entry 226 (class 1259 OID 67919)
-- Name: SIIUP_QUARTER_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_QUARTER_CAT" (
    id bigint NOT NULL,
    name character varying(2) NOT NULL
);


ALTER TABLE public."SIIUP_QUARTER_CAT" OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 67917)
-- Name: SIIUP_QUARTER_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_QUARTER_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_QUARTER_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3474 (class 0 OID 0)
-- Dependencies: 225
-- Name: SIIUP_QUARTER_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_QUARTER_CAT_id_seq" OWNED BY public."SIIUP_QUARTER_CAT".id;


--
-- TOC entry 230 (class 1259 OID 67939)
-- Name: SIIUP_SHIFT_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_SHIFT_CAT" (
    id bigint NOT NULL,
    description character varying(10) NOT NULL,
    abbreviation character varying(1) NOT NULL
);


ALTER TABLE public."SIIUP_SHIFT_CAT" OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 67937)
-- Name: SIIUP_SHIFT_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_SHIFT_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_SHIFT_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3475 (class 0 OID 0)
-- Dependencies: 229
-- Name: SIIUP_SHIFT_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_SHIFT_CAT_id_seq" OWNED BY public."SIIUP_SHIFT_CAT".id;


--
-- TOC entry 234 (class 1259 OID 67959)
-- Name: SIIUP_STUDY_PLAN_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_STUDY_PLAN_CAT" (
    id bigint NOT NULL,
    num_periods integer NOT NULL,
    description character varying(150) NOT NULL,
    authorization_date date NOT NULL,
    num_credits integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    year integer NOT NULL,
    career_id bigint NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_STUDY_PLAN_CAT" OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 67957)
-- Name: SIIUP_STUDY_PLAN_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_STUDY_PLAN_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_STUDY_PLAN_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3476 (class 0 OID 0)
-- Dependencies: 233
-- Name: SIIUP_STUDY_PLAN_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_STUDY_PLAN_CAT_id_seq" OWNED BY public."SIIUP_STUDY_PLAN_CAT".id;


--
-- TOC entry 240 (class 1259 OID 67987)
-- Name: SIIUP_SUBJECT_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_SUBJECT_CAT" (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    code_subject character varying(20) NOT NULL,
    credits integer NOT NULL,
    theoretical_hours integer NOT NULL,
    practical_hours integer NOT NULL,
    certifiable boolean NOT NULL,
    limit_absence integer NOT NULL,
    alumn_load character varying(1) NOT NULL,
    quarter_id bigint NOT NULL,
    status_id bigint NOT NULL,
    study_plan_id bigint NOT NULL,
    training_cycle_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_SUBJECT_CAT" OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 67985)
-- Name: SIIUP_SUBJECT_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_SUBJECT_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_SUBJECT_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3477 (class 0 OID 0)
-- Dependencies: 239
-- Name: SIIUP_SUBJECT_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_SUBJECT_CAT_id_seq" OWNED BY public."SIIUP_SUBJECT_CAT".id;


--
-- TOC entry 259 (class 1259 OID 68281)
-- Name: SIIUP_TEACHER_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_TEACHER_CAT" (
    id bigint NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(15) NOT NULL,
    second_last_name character varying(15) NOT NULL,
    email character varying(254) NOT NULL,
    gender character varying(50) NOT NULL,
    teacher_status_id bigint NOT NULL
);


ALTER TABLE public."SIIUP_TEACHER_CAT" OWNER TO postgres;

--
-- TOC entry 258 (class 1259 OID 68279)
-- Name: SIIUP_TEACHER_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_TEACHER_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_TEACHER_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3478 (class 0 OID 0)
-- Dependencies: 258
-- Name: SIIUP_TEACHER_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_TEACHER_CAT_id_seq" OWNED BY public."SIIUP_TEACHER_CAT".id;


--
-- TOC entry 236 (class 1259 OID 67967)
-- Name: SIIUP_TRAINING_CYCLE_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_TRAINING_CYCLE_CAT" (
    id bigint NOT NULL,
    name character varying(30) NOT NULL
);


ALTER TABLE public."SIIUP_TRAINING_CYCLE_CAT" OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 67965)
-- Name: SIIUP_TRAINING_CYCLE_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_TRAINING_CYCLE_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_TRAINING_CYCLE_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3479 (class 0 OID 0)
-- Dependencies: 235
-- Name: SIIUP_TRAINING_CYCLE_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_TRAINING_CYCLE_CAT_id_seq" OWNED BY public."SIIUP_TRAINING_CYCLE_CAT".id;


--
-- TOC entry 255 (class 1259 OID 68228)
-- Name: SIIUP_TYPE_ALUMN; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_TYPE_ALUMN" (
    id bigint NOT NULL,
    alumns_type character varying(30) NOT NULL,
    description character varying(30) NOT NULL
);


ALTER TABLE public."SIIUP_TYPE_ALUMN" OWNER TO postgres;

--
-- TOC entry 254 (class 1259 OID 68226)
-- Name: SIIUP_TYPE_ALUMN_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_TYPE_ALUMN_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_TYPE_ALUMN_id_seq" OWNER TO postgres;

--
-- TOC entry 3480 (class 0 OID 0)
-- Dependencies: 254
-- Name: SIIUP_TYPE_ALUMN_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_TYPE_ALUMN_id_seq" OWNED BY public."SIIUP_TYPE_ALUMN".id;


--
-- TOC entry 238 (class 1259 OID 67977)
-- Name: SIIUP_TYPE_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIIUP_TYPE_CAT" (
    id bigint NOT NULL,
    name character varying(2) NOT NULL
);


ALTER TABLE public."SIIUP_TYPE_CAT" OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 67975)
-- Name: SIIUP_TYPE_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIIUP_TYPE_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIIUP_TYPE_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3481 (class 0 OID 0)
-- Dependencies: 237
-- Name: SIIUP_TYPE_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIIUP_TYPE_CAT_id_seq" OWNED BY public."SIIUP_TYPE_CAT".id;


--
-- TOC entry 277 (class 1259 OID 68383)
-- Name: SIUUP_ALUM_PRATICES; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIUUP_ALUM_PRATICES" (
    id bigint NOT NULL,
    entry_date timestamp with time zone NOT NULL,
    exit_date timestamp with time zone,
    enrollment_id integer NOT NULL,
    equipment_id bigint NOT NULL,
    laboratory_id bigint,
    program_id bigint,
    schedule_id bigint
);


ALTER TABLE public."SIUUP_ALUM_PRATICES" OWNER TO postgres;

--
-- TOC entry 276 (class 1259 OID 68381)
-- Name: SIUUP_ALUM_PRATICES_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIUUP_ALUM_PRATICES_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIUUP_ALUM_PRATICES_id_seq" OWNER TO postgres;

--
-- TOC entry 3482 (class 0 OID 0)
-- Dependencies: 276
-- Name: SIUUP_ALUM_PRATICES_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIUUP_ALUM_PRATICES_id_seq" OWNED BY public."SIUUP_ALUM_PRATICES".id;


--
-- TOC entry 261 (class 1259 OID 68298)
-- Name: SIUUP_CATEGORIES_EQUIPMENT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIUUP_CATEGORIES_EQUIPMENT" (
    id bigint NOT NULL,
    desciption character varying(30) NOT NULL
);


ALTER TABLE public."SIUUP_CATEGORIES_EQUIPMENT" OWNER TO postgres;

--
-- TOC entry 260 (class 1259 OID 68296)
-- Name: SIUUP_CATEGORIES_EQUIPMENT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIUUP_CATEGORIES_EQUIPMENT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIUUP_CATEGORIES_EQUIPMENT_id_seq" OWNER TO postgres;

--
-- TOC entry 3483 (class 0 OID 0)
-- Dependencies: 260
-- Name: SIUUP_CATEGORIES_EQUIPMENT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIUUP_CATEGORIES_EQUIPMENT_id_seq" OWNED BY public."SIUUP_CATEGORIES_EQUIPMENT".id;


--
-- TOC entry 263 (class 1259 OID 68308)
-- Name: SIUUP_EQUIPMENT_GENERAL; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIUUP_EQUIPMENT_GENERAL" (
    id bigint NOT NULL,
    number integer NOT NULL,
    description text NOT NULL,
    category_id bigint NOT NULL,
    laboratory_id bigint NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public."SIUUP_EQUIPMENT_GENERAL" OWNER TO postgres;

--
-- TOC entry 262 (class 1259 OID 68306)
-- Name: SIUUP_EQUIPMENT_GENERAL_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIUUP_EQUIPMENT_GENERAL_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIUUP_EQUIPMENT_GENERAL_id_seq" OWNER TO postgres;

--
-- TOC entry 3484 (class 0 OID 0)
-- Dependencies: 262
-- Name: SIUUP_EQUIPMENT_GENERAL_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIUUP_EQUIPMENT_GENERAL_id_seq" OWNED BY public."SIUUP_EQUIPMENT_GENERAL".id;


--
-- TOC entry 275 (class 1259 OID 68365)
-- Name: SIUUP_EQUIPMENT_PROGRAM; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIUUP_EQUIPMENT_PROGRAM" (
    id bigint NOT NULL,
    equipment_id bigint NOT NULL,
    prgram_id bigint NOT NULL
);


ALTER TABLE public."SIUUP_EQUIPMENT_PROGRAM" OWNER TO postgres;

--
-- TOC entry 274 (class 1259 OID 68363)
-- Name: SIUUP_EQUIPMENT_PROGRAM_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIUUP_EQUIPMENT_PROGRAM_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIUUP_EQUIPMENT_PROGRAM_id_seq" OWNER TO postgres;

--
-- TOC entry 3485 (class 0 OID 0)
-- Dependencies: 274
-- Name: SIUUP_EQUIPMENT_PROGRAM_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIUUP_EQUIPMENT_PROGRAM_id_seq" OWNED BY public."SIUUP_EQUIPMENT_PROGRAM".id;


--
-- TOC entry 265 (class 1259 OID 68319)
-- Name: SIUUP_LABORATORIES; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIUUP_LABORATORIES" (
    id bigint NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public."SIUUP_LABORATORIES" OWNER TO postgres;

--
-- TOC entry 264 (class 1259 OID 68317)
-- Name: SIUUP_LABORATORIES_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIUUP_LABORATORIES_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIUUP_LABORATORIES_id_seq" OWNER TO postgres;

--
-- TOC entry 3486 (class 0 OID 0)
-- Dependencies: 264
-- Name: SIUUP_LABORATORIES_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIUUP_LABORATORIES_id_seq" OWNED BY public."SIUUP_LABORATORIES".id;


--
-- TOC entry 267 (class 1259 OID 68329)
-- Name: SIUUP_PROGRAMS_CAT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIUUP_PROGRAMS_CAT" (
    id bigint NOT NULL,
    desciption character varying(100) NOT NULL,
    version character varying(20) NOT NULL
);


ALTER TABLE public."SIUUP_PROGRAMS_CAT" OWNER TO postgres;

--
-- TOC entry 266 (class 1259 OID 68327)
-- Name: SIUUP_PROGRAMS_CAT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIUUP_PROGRAMS_CAT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIUUP_PROGRAMS_CAT_id_seq" OWNER TO postgres;

--
-- TOC entry 3487 (class 0 OID 0)
-- Dependencies: 266
-- Name: SIUUP_PROGRAMS_CAT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIUUP_PROGRAMS_CAT_id_seq" OWNED BY public."SIUUP_PROGRAMS_CAT".id;


--
-- TOC entry 269 (class 1259 OID 68339)
-- Name: SIUUP_SCHEDULE; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIUUP_SCHEDULE" (
    id bigint NOT NULL,
    day character varying(15) NOT NULL,
    time_start time without time zone NOT NULL,
    time_end time without time zone NOT NULL,
    "Laboratory_id" bigint NOT NULL,
    group_id bigint NOT NULL,
    period_id bigint NOT NULL,
    status_id bigint NOT NULL,
    subject_id bigint NOT NULL,
    teacher_id bigint NOT NULL
);


ALTER TABLE public."SIUUP_SCHEDULE" OWNER TO postgres;

--
-- TOC entry 268 (class 1259 OID 68337)
-- Name: SIUUP_SCHEDULE_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIUUP_SCHEDULE_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIUUP_SCHEDULE_id_seq" OWNER TO postgres;

--
-- TOC entry 3488 (class 0 OID 0)
-- Dependencies: 268
-- Name: SIUUP_SCHEDULE_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIUUP_SCHEDULE_id_seq" OWNED BY public."SIUUP_SCHEDULE".id;


--
-- TOC entry 232 (class 1259 OID 67947)
-- Name: SIUUP_STATUS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIUUP_STATUS" (
    id bigint NOT NULL,
    status character varying(20) NOT NULL,
    description character varying(50) NOT NULL
);


ALTER TABLE public."SIUUP_STATUS" OWNER TO postgres;

--
-- TOC entry 271 (class 1259 OID 68347)
-- Name: SIUUP_STATUS_EQUIPMENT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIUUP_STATUS_EQUIPMENT" (
    id bigint NOT NULL,
    desciption character varying(25) NOT NULL
);


ALTER TABLE public."SIUUP_STATUS_EQUIPMENT" OWNER TO postgres;

--
-- TOC entry 270 (class 1259 OID 68345)
-- Name: SIUUP_STATUS_EQUIPMENT_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIUUP_STATUS_EQUIPMENT_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIUUP_STATUS_EQUIPMENT_id_seq" OWNER TO postgres;

--
-- TOC entry 3489 (class 0 OID 0)
-- Dependencies: 270
-- Name: SIUUP_STATUS_EQUIPMENT_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIUUP_STATUS_EQUIPMENT_id_seq" OWNED BY public."SIUUP_STATUS_EQUIPMENT".id;


--
-- TOC entry 231 (class 1259 OID 67945)
-- Name: SIUUP_STATUS_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIUUP_STATUS_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIUUP_STATUS_id_seq" OWNER TO postgres;

--
-- TOC entry 3490 (class 0 OID 0)
-- Dependencies: 231
-- Name: SIUUP_STATUS_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIUUP_STATUS_id_seq" OWNED BY public."SIUUP_STATUS".id;


--
-- TOC entry 273 (class 1259 OID 68357)
-- Name: SIUUP_TEACHER_PRACTICES; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SIUUP_TEACHER_PRACTICES" (
    id bigint NOT NULL,
    entry_date timestamp with time zone NOT NULL,
    exit_date timestamp with time zone,
    description character varying(250) NOT NULL,
    equipment_id bigint,
    laboratory_id bigint NOT NULL,
    schedule_id bigint,
    teacher_id bigint NOT NULL
);


ALTER TABLE public."SIUUP_TEACHER_PRACTICES" OWNER TO postgres;

--
-- TOC entry 272 (class 1259 OID 68355)
-- Name: SIUUP_TEACHER_PRACTICES_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SIUUP_TEACHER_PRACTICES_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SIUUP_TEACHER_PRACTICES_id_seq" OWNER TO postgres;

--
-- TOC entry 3491 (class 0 OID 0)
-- Dependencies: 272
-- Name: SIUUP_TEACHER_PRACTICES_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SIUUP_TEACHER_PRACTICES_id_seq" OWNED BY public."SIUUP_TEACHER_PRACTICES".id;


--
-- TOC entry 203 (class 1259 OID 67726)
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- TOC entry 202 (class 1259 OID 67724)
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- TOC entry 3492 (class 0 OID 0)
-- Dependencies: 202
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- TOC entry 205 (class 1259 OID 67736)
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- TOC entry 204 (class 1259 OID 67734)
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- TOC entry 3493 (class 0 OID 0)
-- Dependencies: 204
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- TOC entry 201 (class 1259 OID 67718)
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- TOC entry 200 (class 1259 OID 67716)
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- TOC entry 3494 (class 0 OID 0)
-- Dependencies: 200
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- TOC entry 207 (class 1259 OID 67744)
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- TOC entry 209 (class 1259 OID 67754)
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- TOC entry 208 (class 1259 OID 67752)
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- TOC entry 3495 (class 0 OID 0)
-- Dependencies: 208
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- TOC entry 206 (class 1259 OID 67742)
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- TOC entry 3496 (class 0 OID 0)
-- Dependencies: 206
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- TOC entry 211 (class 1259 OID 67762)
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- TOC entry 210 (class 1259 OID 67760)
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- TOC entry 3497 (class 0 OID 0)
-- Dependencies: 210
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- TOC entry 213 (class 1259 OID 67822)
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- TOC entry 212 (class 1259 OID 67820)
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- TOC entry 3498 (class 0 OID 0)
-- Dependencies: 212
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- TOC entry 199 (class 1259 OID 67708)
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- TOC entry 198 (class 1259 OID 67706)
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- TOC entry 3499 (class 0 OID 0)
-- Dependencies: 198
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- TOC entry 197 (class 1259 OID 67697)
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- TOC entry 196 (class 1259 OID 67695)
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- TOC entry 3500 (class 0 OID 0)
-- Dependencies: 196
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- TOC entry 214 (class 1259 OID 67853)
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- TOC entry 2933 (class 2604 OID 67932)
-- Name: SIIIP_ROLES_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIIP_ROLES_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIIP_ROLES_CAT_id_seq"'::regclass);


--
-- TOC entry 2947 (class 2604 OID 68239)
-- Name: SIIUP_ALUMN_ESC_DET id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_ALUMN_ESC_DET" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_ALUMN_ESC_DET_id_seq"'::regclass);


--
-- TOC entry 2927 (class 2604 OID 67868)
-- Name: SIIUP_CAREER_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_CAREER_CAT_id_seq"'::regclass);


--
-- TOC entry 2945 (class 2604 OID 68079)
-- Name: SIIUP_CAREER_SUBJECT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_SUBJECT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_CAREER_SUBJECT_id_seq"'::regclass);


--
-- TOC entry 2928 (class 2604 OID 67882)
-- Name: SIIUP_CHARGE id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CHARGE" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_CHARGE_id_seq"'::regclass);


--
-- TOC entry 2929 (class 2604 OID 67894)
-- Name: SIIUP_CYCLE_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CYCLE_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_CYCLE_CAT_id_seq"'::regclass);


--
-- TOC entry 2930 (class 2604 OID 67904)
-- Name: SIIUP_GENERATION_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GENERATION_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_GENERATION_CAT_id_seq"'::regclass);


--
-- TOC entry 2931 (class 2604 OID 67914)
-- Name: SIIUP_GROUP_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_GROUP_CAT_id_seq"'::regclass);


--
-- TOC entry 2944 (class 2604 OID 68036)
-- Name: SIIUP_GROUP_SUBJECT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_SUBJECT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_GROUP_SUBJECT_id_seq"'::regclass);


--
-- TOC entry 2943 (class 2604 OID 68026)
-- Name: SIIUP_GROUP_TYPE_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_TYPE_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_GROUP_TYPE_CAT_id_seq"'::regclass);


--
-- TOC entry 2942 (class 2604 OID 68016)
-- Name: SIIUP_MODALITY_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_MODALITY_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_MODALITY_CAT_id_seq"'::regclass);


--
-- TOC entry 2941 (class 2604 OID 68008)
-- Name: SIIUP_PERIOD_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_PERIOD_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_PERIOD_CAT_id_seq"'::regclass);


--
-- TOC entry 2940 (class 2604 OID 67998)
-- Name: SIIUP_QUALIFICATION_TYPE_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_QUALIFICATION_TYPE_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_QUALIFICATION_TYPE_CAT_id_seq"'::regclass);


--
-- TOC entry 2932 (class 2604 OID 67922)
-- Name: SIIUP_QUARTER_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_QUARTER_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_QUARTER_CAT_id_seq"'::regclass);


--
-- TOC entry 2934 (class 2604 OID 67942)
-- Name: SIIUP_SHIFT_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_SHIFT_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_SHIFT_CAT_id_seq"'::regclass);


--
-- TOC entry 2936 (class 2604 OID 67962)
-- Name: SIIUP_STUDY_PLAN_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_STUDY_PLAN_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_STUDY_PLAN_CAT_id_seq"'::regclass);


--
-- TOC entry 2939 (class 2604 OID 67990)
-- Name: SIIUP_SUBJECT_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_SUBJECT_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_SUBJECT_CAT_id_seq"'::regclass);


--
-- TOC entry 2948 (class 2604 OID 68284)
-- Name: SIIUP_TEACHER_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TEACHER_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_TEACHER_CAT_id_seq"'::regclass);


--
-- TOC entry 2937 (class 2604 OID 67970)
-- Name: SIIUP_TRAINING_CYCLE_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TRAINING_CYCLE_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_TRAINING_CYCLE_CAT_id_seq"'::regclass);


--
-- TOC entry 2946 (class 2604 OID 68231)
-- Name: SIIUP_TYPE_ALUMN id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TYPE_ALUMN" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_TYPE_ALUMN_id_seq"'::regclass);


--
-- TOC entry 2938 (class 2604 OID 67980)
-- Name: SIIUP_TYPE_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TYPE_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIIUP_TYPE_CAT_id_seq"'::regclass);


--
-- TOC entry 2957 (class 2604 OID 68386)
-- Name: SIUUP_ALUM_PRATICES id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_ALUM_PRATICES" ALTER COLUMN id SET DEFAULT nextval('public."SIUUP_ALUM_PRATICES_id_seq"'::regclass);


--
-- TOC entry 2949 (class 2604 OID 68301)
-- Name: SIUUP_CATEGORIES_EQUIPMENT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_CATEGORIES_EQUIPMENT" ALTER COLUMN id SET DEFAULT nextval('public."SIUUP_CATEGORIES_EQUIPMENT_id_seq"'::regclass);


--
-- TOC entry 2950 (class 2604 OID 68311)
-- Name: SIUUP_EQUIPMENT_GENERAL id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_EQUIPMENT_GENERAL" ALTER COLUMN id SET DEFAULT nextval('public."SIUUP_EQUIPMENT_GENERAL_id_seq"'::regclass);


--
-- TOC entry 2956 (class 2604 OID 68368)
-- Name: SIUUP_EQUIPMENT_PROGRAM id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_EQUIPMENT_PROGRAM" ALTER COLUMN id SET DEFAULT nextval('public."SIUUP_EQUIPMENT_PROGRAM_id_seq"'::regclass);


--
-- TOC entry 2951 (class 2604 OID 68322)
-- Name: SIUUP_LABORATORIES id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_LABORATORIES" ALTER COLUMN id SET DEFAULT nextval('public."SIUUP_LABORATORIES_id_seq"'::regclass);


--
-- TOC entry 2952 (class 2604 OID 68332)
-- Name: SIUUP_PROGRAMS_CAT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_PROGRAMS_CAT" ALTER COLUMN id SET DEFAULT nextval('public."SIUUP_PROGRAMS_CAT_id_seq"'::regclass);


--
-- TOC entry 2953 (class 2604 OID 68342)
-- Name: SIUUP_SCHEDULE id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_SCHEDULE" ALTER COLUMN id SET DEFAULT nextval('public."SIUUP_SCHEDULE_id_seq"'::regclass);


--
-- TOC entry 2935 (class 2604 OID 67950)
-- Name: SIUUP_STATUS id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_STATUS" ALTER COLUMN id SET DEFAULT nextval('public."SIUUP_STATUS_id_seq"'::regclass);


--
-- TOC entry 2954 (class 2604 OID 68350)
-- Name: SIUUP_STATUS_EQUIPMENT id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_STATUS_EQUIPMENT" ALTER COLUMN id SET DEFAULT nextval('public."SIUUP_STATUS_EQUIPMENT_id_seq"'::regclass);


--
-- TOC entry 2955 (class 2604 OID 68360)
-- Name: SIUUP_TEACHER_PRACTICES id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_TEACHER_PRACTICES" ALTER COLUMN id SET DEFAULT nextval('public."SIUUP_TEACHER_PRACTICES_id_seq"'::regclass);


--
-- TOC entry 2920 (class 2604 OID 67729)
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- TOC entry 2921 (class 2604 OID 67739)
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- TOC entry 2919 (class 2604 OID 67721)
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- TOC entry 2922 (class 2604 OID 67747)
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- TOC entry 2923 (class 2604 OID 67757)
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- TOC entry 2924 (class 2604 OID 67765)
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- TOC entry 2925 (class 2604 OID 67825)
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- TOC entry 2918 (class 2604 OID 67711)
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- TOC entry 2917 (class 2604 OID 67700)
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- TOC entry 3403 (class 0 OID 67929)
-- Dependencies: 228
-- Data for Name: SIIIP_ROLES_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIIP_ROLES_CAT" (id, description) FROM stdin;
\.


--
-- TOC entry 3428 (class 0 OID 68219)
-- Dependencies: 253
-- Data for Name: SIIUP_ALUMN_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_ALUMN_CAT" (enrollment, first_name, last_name, second_last_name, gender, email) FROM stdin;
\.


--
-- TOC entry 3432 (class 0 OID 68236)
-- Dependencies: 257
-- Data for Name: SIIUP_ALUMN_ESC_DET; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_ALUMN_ESC_DET" (id, other_procedence_school, highschool_area, average, location, date_admission, date_egress, enrollment_id, generation_id, group_id, period_id, postgraduate_id, status_id) FROM stdin;
\.


--
-- TOC entry 3391 (class 0 OID 67865)
-- Dependencies: 216
-- Data for Name: SIIUP_CAREER_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_CAREER_CAT" (id, academic_program_name, homosigla, academic_program_name_gdp, modality_id, status_id) FROM stdin;
\.


--
-- TOC entry 3427 (class 0 OID 68076)
-- Dependencies: 252
-- Data for Name: SIIUP_CAREER_SUBJECT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_CAREER_SUBJECT" (id, career_id, subject_id) FROM stdin;
\.


--
-- TOC entry 3393 (class 0 OID 67879)
-- Dependencies: 218
-- Data for Name: SIIUP_CHARGE; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_CHARGE" (id, charge, description) FROM stdin;
\.


--
-- TOC entry 3395 (class 0 OID 67891)
-- Dependencies: 220
-- Data for Name: SIIUP_CYCLE_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_CYCLE_CAT" (id, name, start_date, end_date, status_id) FROM stdin;
\.


--
-- TOC entry 3397 (class 0 OID 67901)
-- Dependencies: 222
-- Data for Name: SIIUP_GENERATION_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_GENERATION_CAT" (id, description, status_id) FROM stdin;
\.


--
-- TOC entry 3399 (class 0 OID 67911)
-- Dependencies: 224
-- Data for Name: SIIUP_GROUP_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_GROUP_CAT" (id, "group", availability, code, career_id, generation_id, group_type_id, period_id, quarter_id, shift_id, status_id) FROM stdin;
\.


--
-- TOC entry 3425 (class 0 OID 68033)
-- Dependencies: 250
-- Data for Name: SIIUP_GROUP_SUBJECT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_GROUP_SUBJECT" (id, group_id, subject_id) FROM stdin;
\.


--
-- TOC entry 3423 (class 0 OID 68023)
-- Dependencies: 248
-- Data for Name: SIIUP_GROUP_TYPE_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_GROUP_TYPE_CAT" (id, description, status_id) FROM stdin;
\.


--
-- TOC entry 3421 (class 0 OID 68013)
-- Dependencies: 246
-- Data for Name: SIIUP_MODALITY_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_MODALITY_CAT" (id, description, status_id) FROM stdin;
\.


--
-- TOC entry 3419 (class 0 OID 68005)
-- Dependencies: 244
-- Data for Name: SIIUP_PERIOD_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_PERIOD_CAT" (id, name, start_date, end_date, vacational_start_date, vacational_end_date, cycle_id, status_id) FROM stdin;
\.


--
-- TOC entry 3417 (class 0 OID 67995)
-- Dependencies: 242
-- Data for Name: SIIUP_QUALIFICATION_TYPE_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_QUALIFICATION_TYPE_CAT" (id, description, status_id) FROM stdin;
\.


--
-- TOC entry 3401 (class 0 OID 67919)
-- Dependencies: 226
-- Data for Name: SIIUP_QUARTER_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_QUARTER_CAT" (id, name) FROM stdin;
\.


--
-- TOC entry 3405 (class 0 OID 67939)
-- Dependencies: 230
-- Data for Name: SIIUP_SHIFT_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_SHIFT_CAT" (id, description, abbreviation) FROM stdin;
\.


--
-- TOC entry 3409 (class 0 OID 67959)
-- Dependencies: 234
-- Data for Name: SIIUP_STUDY_PLAN_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_STUDY_PLAN_CAT" (id, num_periods, description, authorization_date, num_credits, start_date, end_date, year, career_id, status_id) FROM stdin;
\.


--
-- TOC entry 3415 (class 0 OID 67987)
-- Dependencies: 240
-- Data for Name: SIIUP_SUBJECT_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_SUBJECT_CAT" (id, name, code_subject, credits, theoretical_hours, practical_hours, certifiable, limit_absence, alumn_load, quarter_id, status_id, study_plan_id, training_cycle_id) FROM stdin;
\.


--
-- TOC entry 3434 (class 0 OID 68281)
-- Dependencies: 259
-- Data for Name: SIIUP_TEACHER_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_TEACHER_CAT" (id, first_name, last_name, second_last_name, email, gender, teacher_status_id) FROM stdin;
\.


--
-- TOC entry 3411 (class 0 OID 67967)
-- Dependencies: 236
-- Data for Name: SIIUP_TRAINING_CYCLE_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_TRAINING_CYCLE_CAT" (id, name) FROM stdin;
\.


--
-- TOC entry 3430 (class 0 OID 68228)
-- Dependencies: 255
-- Data for Name: SIIUP_TYPE_ALUMN; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_TYPE_ALUMN" (id, alumns_type, description) FROM stdin;
\.


--
-- TOC entry 3413 (class 0 OID 67977)
-- Dependencies: 238
-- Data for Name: SIIUP_TYPE_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIIUP_TYPE_CAT" (id, name) FROM stdin;
\.


--
-- TOC entry 3452 (class 0 OID 68383)
-- Dependencies: 277
-- Data for Name: SIUUP_ALUM_PRATICES; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIUUP_ALUM_PRATICES" (id, entry_date, exit_date, enrollment_id, equipment_id, laboratory_id, program_id, schedule_id) FROM stdin;
\.


--
-- TOC entry 3436 (class 0 OID 68298)
-- Dependencies: 261
-- Data for Name: SIUUP_CATEGORIES_EQUIPMENT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIUUP_CATEGORIES_EQUIPMENT" (id, desciption) FROM stdin;
\.


--
-- TOC entry 3438 (class 0 OID 68308)
-- Dependencies: 263
-- Data for Name: SIUUP_EQUIPMENT_GENERAL; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIUUP_EQUIPMENT_GENERAL" (id, number, description, category_id, laboratory_id, status_id) FROM stdin;
\.


--
-- TOC entry 3450 (class 0 OID 68365)
-- Dependencies: 275
-- Data for Name: SIUUP_EQUIPMENT_PROGRAM; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIUUP_EQUIPMENT_PROGRAM" (id, equipment_id, prgram_id) FROM stdin;
\.


--
-- TOC entry 3440 (class 0 OID 68319)
-- Dependencies: 265
-- Data for Name: SIUUP_LABORATORIES; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIUUP_LABORATORIES" (id, name) FROM stdin;
\.


--
-- TOC entry 3442 (class 0 OID 68329)
-- Dependencies: 267
-- Data for Name: SIUUP_PROGRAMS_CAT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIUUP_PROGRAMS_CAT" (id, desciption, version) FROM stdin;
\.


--
-- TOC entry 3444 (class 0 OID 68339)
-- Dependencies: 269
-- Data for Name: SIUUP_SCHEDULE; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIUUP_SCHEDULE" (id, day, time_start, time_end, "Laboratory_id", group_id, period_id, status_id, subject_id, teacher_id) FROM stdin;
\.


--
-- TOC entry 3407 (class 0 OID 67947)
-- Dependencies: 232
-- Data for Name: SIUUP_STATUS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIUUP_STATUS" (id, status, description) FROM stdin;
\.


--
-- TOC entry 3446 (class 0 OID 68347)
-- Dependencies: 271
-- Data for Name: SIUUP_STATUS_EQUIPMENT; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIUUP_STATUS_EQUIPMENT" (id, desciption) FROM stdin;
\.


--
-- TOC entry 3448 (class 0 OID 68357)
-- Dependencies: 273
-- Data for Name: SIUUP_TEACHER_PRACTICES; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SIUUP_TEACHER_PRACTICES" (id, entry_date, exit_date, description, equipment_id, laboratory_id, schedule_id, teacher_id) FROM stdin;
\.


--
-- TOC entry 3378 (class 0 OID 67726)
-- Dependencies: 203
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- TOC entry 3380 (class 0 OID 67736)
-- Dependencies: 205
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- TOC entry 3376 (class 0 OID 67718)
-- Dependencies: 201
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add Estado	7	add_statusmodel
26	Can change Estado	7	change_statusmodel
27	Can delete Estado	7	delete_statusmodel
28	Can view Estado	7	view_statusmodel
29	Can add Rol	8	add_rolmodel
30	Can change Rol	8	change_rolmodel
31	Can delete Rol	8	delete_rolmodel
32	Can view Rol	8	view_rolmodel
33	Can add Cargo	9	add_chargemodel
34	Can change Cargo	9	change_chargemodel
35	Can delete Cargo	9	delete_chargemodel
36	Can view Cargo	9	view_chargemodel
37	Can add Modalidad	10	add_modalitymodel
38	Can change Modalidad	10	change_modalitymodel
39	Can delete Modalidad	10	delete_modalitymodel
40	Can view Modalidad	10	view_modalitymodel
41	Can add Carrera	11	add_careermodel
42	Can change Carrera	11	change_careermodel
43	Can delete Carrera	11	delete_careermodel
44	Can view Carrera	11	view_careermodel
45	Can add Cuatrimestre	12	add_quartermodel
46	Can change Cuatrimestre	12	change_quartermodel
47	Can delete Cuatrimestre	12	delete_quartermodel
48	Can view Cuatrimestre	12	view_quartermodel
49	Can add Tipo	13	add_typemodel
50	Can change Tipo	13	change_typemodel
51	Can delete Tipo	13	delete_typemodel
52	Can view Tipo	13	view_typemodel
53	Can add Ciclo	14	add_cyclemodel
54	Can change Ciclo	14	change_cyclemodel
55	Can delete Ciclo	14	delete_cyclemodel
56	Can view Ciclo	14	view_cyclemodel
57	Can add Periodo	15	add_periodmodel
58	Can change Periodo	15	change_periodmodel
59	Can delete Periodo	15	delete_periodmodel
60	Can view Periodo	15	view_periodmodel
61	Can add Generación	16	add_generationmodel
62	Can change Generación	16	change_generationmodel
63	Can delete Generación	16	delete_generationmodel
64	Can view Generación	16	view_generationmodel
65	Can add Tipo de calificacion	17	add_qualificationtypemodel
66	Can change Tipo de calificacion	17	change_qualificationtypemodel
67	Can delete Tipo de calificacion	17	delete_qualificationtypemodel
68	Can view Tipo de calificacion	17	view_qualificationtypemodel
69	Can add Tipo grupo	18	add_grouptypemodel
70	Can change Tipo grupo	18	change_grouptypemodel
71	Can delete Tipo grupo	18	delete_grouptypemodel
72	Can view Tipo grupo	18	view_grouptypemodel
73	Can add Ciclo de formación	19	add_trainingcyclemodel
74	Can change Ciclo de formación	19	change_trainingcyclemodel
75	Can delete Ciclo de formación	19	delete_trainingcyclemodel
76	Can view Ciclo de formación	19	view_trainingcyclemodel
77	Can add Plan de estudio	20	add_studyplanmodel
78	Can change Plan de estudio	20	change_studyplanmodel
79	Can delete Plan de estudio	20	delete_studyplanmodel
80	Can view Plan de estudio	20	view_studyplanmodel
81	Can add Asignatura	21	add_subjectmodel
82	Can change Asignatura	21	change_subjectmodel
83	Can delete Asignatura	21	delete_subjectmodel
84	Can view Asignatura	21	view_subjectmodel
85	Can add Carrera asignatura	22	add_careersubjectmodel
86	Can change Carrera asignatura	22	change_careersubjectmodel
87	Can delete Carrera asignatura	22	delete_careersubjectmodel
88	Can view Carrera asignatura	22	view_careersubjectmodel
89	Can add Turno	23	add_shiftmodel
90	Can change Turno	23	change_shiftmodel
91	Can delete Turno	23	delete_shiftmodel
92	Can view Turno	23	view_shiftmodel
93	Can add Grupo	24	add_groupmodel
94	Can change Grupo	24	change_groupmodel
95	Can delete Grupo	24	delete_groupmodel
96	Can view Grupo	24	view_groupmodel
97	Can add Grupo asignatura	25	add_groupsubjectmodel
98	Can change Grupo asignatura	25	change_groupsubjectmodel
99	Can delete Grupo asignatura	25	delete_groupsubjectmodel
100	Can view Grupo asignatura	25	view_groupsubjectmodel
101	Can add Tipo de alumno	26	add_alumntypemodel
102	Can change Tipo de alumno	26	change_alumntypemodel
103	Can delete Tipo de alumno	26	delete_alumntypemodel
104	Can view Tipo de alumno	26	view_alumntypemodel
105	Can add Alumno	27	add_alumnmodel
106	Can change Alumno	27	change_alumnmodel
107	Can delete Alumno	27	delete_alumnmodel
108	Can view Alumno	27	view_alumnmodel
109	Can add Escolaridad	28	add_alumnschooldatamodel
110	Can change Escolaridad	28	change_alumnschooldatamodel
111	Can delete Escolaridad	28	delete_alumnschooldatamodel
112	Can view Escolaridad	28	view_alumnschooldatamodel
113	Can add Laboratorio	29	add_laboratorymodel
114	Can change Laboratorio	29	change_laboratorymodel
115	Can delete Laboratorio	29	delete_laboratorymodel
116	Can view Laboratorio	29	view_laboratorymodel
117	Can add Estado de Equipo	30	add_statusequipmentmodel
118	Can change Estado de Equipo	30	change_statusequipmentmodel
119	Can delete Estado de Equipo	30	delete_statusequipmentmodel
120	Can view Estado de Equipo	30	view_statusequipmentmodel
121	Can add Categoria de Equipo	31	add_categoryequipmentmodel
122	Can change Categoria de Equipo	31	change_categoryequipmentmodel
123	Can delete Categoria de Equipo	31	delete_categoryequipmentmodel
124	Can view Categoria de Equipo	31	view_categoryequipmentmodel
125	Can add Equipo General	32	add_equipmentgeneralmodel
126	Can change Equipo General	32	change_equipmentgeneralmodel
127	Can delete Equipo General	32	delete_equipmentgeneralmodel
128	Can view Equipo General	32	view_equipmentgeneralmodel
129	Can add Programa	33	add_programmodel
130	Can change Programa	33	change_programmodel
131	Can delete Programa	33	delete_programmodel
132	Can view Programa	33	view_programmodel
133	Can add Programa Equipo	34	add_equipmentprogrammodel
134	Can change Programa Equipo	34	change_equipmentprogrammodel
135	Can delete Programa Equipo	34	delete_equipmentprogrammodel
136	Can view Programa Equipo	34	view_equipmentprogrammodel
137	Can add Horario	35	add_schedulemodel
138	Can change Horario	35	change_schedulemodel
139	Can delete Horario	35	delete_schedulemodel
140	Can view Horario	35	view_schedulemodel
141	Can add Practica Alumno	36	add_alumpraticesmodel
142	Can change Practica Alumno	36	change_alumpraticesmodel
143	Can delete Practica Alumno	36	delete_alumpraticesmodel
144	Can view Practica Alumno	36	view_alumpraticesmodel
145	Can add Practica Docente	37	add_teacherpratcesmodel
146	Can change Practica Docente	37	change_teacherpratcesmodel
147	Can delete Practica Docente	37	delete_teacherpratcesmodel
148	Can view Practica Docente	37	view_teacherpratcesmodel
149	Can add Docente	38	add_teachermodel
150	Can change Docente	38	change_teachermodel
151	Can delete Docente	38	delete_teachermodel
152	Can view Docente	38	view_teachermodel
\.


--
-- TOC entry 3382 (class 0 OID 67744)
-- Dependencies: 207
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$320000$GBfiT3aPCubdWBfYUb2w5E$SCSHhuE1VLWLgjwkaP0qBgxP+rE79Li8bBEu6bZktXQ=	2022-05-27 12:55:16.525153-05	t	jorge				t	t	2022-05-27 12:54:58.750306-05
\.


--
-- TOC entry 3384 (class 0 OID 67754)
-- Dependencies: 209
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- TOC entry 3386 (class 0 OID 67762)
-- Dependencies: 211
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- TOC entry 3388 (class 0 OID 67822)
-- Dependencies: 213
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- TOC entry 3374 (class 0 OID 67708)
-- Dependencies: 199
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	main	statusmodel
8	main	rolmodel
9	main	chargemodel
10	main	modalitymodel
11	main	careermodel
12	main	quartermodel
13	main	typemodel
14	main	cyclemodel
15	main	periodmodel
16	main	generationmodel
17	main	qualificationtypemodel
18	main	grouptypemodel
19	main	trainingcyclemodel
20	main	studyplanmodel
21	main	subjectmodel
22	main	careersubjectmodel
23	main	shiftmodel
24	main	groupmodel
25	main	groupsubjectmodel
26	alumn	alumntypemodel
27	alumn	alumnmodel
28	alumn	alumnschooldatamodel
29	laboratory	laboratorymodel
30	laboratory	statusequipmentmodel
31	laboratory	categoryequipmentmodel
32	laboratory	equipmentgeneralmodel
33	laboratory	programmodel
34	laboratory	equipmentprogrammodel
35	laboratory	schedulemodel
36	laboratory	alumpraticesmodel
37	laboratory	teacherpratcesmodel
38	teacher	teachermodel
\.


--
-- TOC entry 3372 (class 0 OID 67697)
-- Dependencies: 197
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2022-05-27 12:53:18.186411-05
2	auth	0001_initial	2022-05-27 12:53:18.370176-05
3	admin	0001_initial	2022-05-27 12:53:18.418178-05
4	admin	0002_logentry_remove_auto_add	2022-05-27 12:53:18.430175-05
5	admin	0003_logentry_add_action_flag_choices	2022-05-27 12:53:18.44418-05
6	contenttypes	0002_remove_content_type_name	2022-05-27 12:53:18.484176-05
7	auth	0002_alter_permission_name_max_length	2022-05-27 12:53:18.500179-05
8	auth	0003_alter_user_email_max_length	2022-05-27 12:53:18.512177-05
9	auth	0004_alter_user_username_opts	2022-05-27 12:53:18.522178-05
10	auth	0005_alter_user_last_login_null	2022-05-27 12:53:18.533177-05
11	auth	0006_require_contenttypes_0002	2022-05-27 12:53:18.535177-05
12	auth	0007_alter_validators_add_error_messages	2022-05-27 12:53:18.546176-05
13	auth	0008_alter_user_username_max_length	2022-05-27 12:53:18.568177-05
14	auth	0009_alter_user_last_name_max_length	2022-05-27 12:53:18.583178-05
15	auth	0010_alter_group_name_max_length	2022-05-27 12:53:18.628178-05
16	auth	0011_update_proxy_permissions	2022-05-27 12:53:18.654177-05
17	auth	0012_alter_user_first_name_max_length	2022-05-27 12:53:18.663175-05
18	sessions	0001_initial	2022-05-27 12:53:18.686991-05
19	main	0001_initial	2022-05-27 12:54:21.312047-05
20	alumn	0001_initial	2022-05-27 12:54:21.424213-05
21	teacher	0001_initial	2022-05-27 12:54:21.467209-05
22	laboratory	0001_initial	2022-05-27 12:54:21.783113-05
\.


--
-- TOC entry 3389 (class 0 OID 67853)
-- Dependencies: 214
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
q5yp0gbtkhwudvh7ayve58vg7nfv8lz6	.eJxVjDEOwjAMRe-SGUU4rkPKyN4zVI5tSAG1UtNOiLtDpQ6w_vfef7me16X0a7W5H9SdHbjD75ZZHjZuQO883iYv07jMQ_ab4ndafTepPS-7-3dQuJZvbZiiJIRGYkumdmVCzIgUkh4xRGJpKCemGFQinKCFNgWCIKQGEdz7A8zFNuE:1nueBA:5OeLbYog6kMs-wrcRMH0_WdDYgMbz5_fGKJYatCF69o	2022-06-10 12:55:16.528153-05
\.


--
-- TOC entry 3501 (class 0 OID 0)
-- Dependencies: 227
-- Name: SIIIP_ROLES_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIIP_ROLES_CAT_id_seq"', 1, false);


--
-- TOC entry 3502 (class 0 OID 0)
-- Dependencies: 256
-- Name: SIIUP_ALUMN_ESC_DET_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_ALUMN_ESC_DET_id_seq"', 1, false);


--
-- TOC entry 3503 (class 0 OID 0)
-- Dependencies: 215
-- Name: SIIUP_CAREER_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_CAREER_CAT_id_seq"', 1, false);


--
-- TOC entry 3504 (class 0 OID 0)
-- Dependencies: 251
-- Name: SIIUP_CAREER_SUBJECT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_CAREER_SUBJECT_id_seq"', 1, false);


--
-- TOC entry 3505 (class 0 OID 0)
-- Dependencies: 217
-- Name: SIIUP_CHARGE_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_CHARGE_id_seq"', 1, false);


--
-- TOC entry 3506 (class 0 OID 0)
-- Dependencies: 219
-- Name: SIIUP_CYCLE_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_CYCLE_CAT_id_seq"', 1, false);


--
-- TOC entry 3507 (class 0 OID 0)
-- Dependencies: 221
-- Name: SIIUP_GENERATION_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_GENERATION_CAT_id_seq"', 1, false);


--
-- TOC entry 3508 (class 0 OID 0)
-- Dependencies: 223
-- Name: SIIUP_GROUP_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_GROUP_CAT_id_seq"', 1, false);


--
-- TOC entry 3509 (class 0 OID 0)
-- Dependencies: 249
-- Name: SIIUP_GROUP_SUBJECT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_GROUP_SUBJECT_id_seq"', 1, false);


--
-- TOC entry 3510 (class 0 OID 0)
-- Dependencies: 247
-- Name: SIIUP_GROUP_TYPE_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_GROUP_TYPE_CAT_id_seq"', 1, false);


--
-- TOC entry 3511 (class 0 OID 0)
-- Dependencies: 245
-- Name: SIIUP_MODALITY_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_MODALITY_CAT_id_seq"', 1, false);


--
-- TOC entry 3512 (class 0 OID 0)
-- Dependencies: 243
-- Name: SIIUP_PERIOD_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_PERIOD_CAT_id_seq"', 1, false);


--
-- TOC entry 3513 (class 0 OID 0)
-- Dependencies: 241
-- Name: SIIUP_QUALIFICATION_TYPE_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_QUALIFICATION_TYPE_CAT_id_seq"', 1, false);


--
-- TOC entry 3514 (class 0 OID 0)
-- Dependencies: 225
-- Name: SIIUP_QUARTER_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_QUARTER_CAT_id_seq"', 1, false);


--
-- TOC entry 3515 (class 0 OID 0)
-- Dependencies: 229
-- Name: SIIUP_SHIFT_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_SHIFT_CAT_id_seq"', 1, false);


--
-- TOC entry 3516 (class 0 OID 0)
-- Dependencies: 233
-- Name: SIIUP_STUDY_PLAN_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_STUDY_PLAN_CAT_id_seq"', 1, false);


--
-- TOC entry 3517 (class 0 OID 0)
-- Dependencies: 239
-- Name: SIIUP_SUBJECT_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_SUBJECT_CAT_id_seq"', 1, false);


--
-- TOC entry 3518 (class 0 OID 0)
-- Dependencies: 258
-- Name: SIIUP_TEACHER_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_TEACHER_CAT_id_seq"', 1, false);


--
-- TOC entry 3519 (class 0 OID 0)
-- Dependencies: 235
-- Name: SIIUP_TRAINING_CYCLE_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_TRAINING_CYCLE_CAT_id_seq"', 1, false);


--
-- TOC entry 3520 (class 0 OID 0)
-- Dependencies: 254
-- Name: SIIUP_TYPE_ALUMN_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_TYPE_ALUMN_id_seq"', 1, false);


--
-- TOC entry 3521 (class 0 OID 0)
-- Dependencies: 237
-- Name: SIIUP_TYPE_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIIUP_TYPE_CAT_id_seq"', 1, false);


--
-- TOC entry 3522 (class 0 OID 0)
-- Dependencies: 276
-- Name: SIUUP_ALUM_PRATICES_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIUUP_ALUM_PRATICES_id_seq"', 1, false);


--
-- TOC entry 3523 (class 0 OID 0)
-- Dependencies: 260
-- Name: SIUUP_CATEGORIES_EQUIPMENT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIUUP_CATEGORIES_EQUIPMENT_id_seq"', 1, false);


--
-- TOC entry 3524 (class 0 OID 0)
-- Dependencies: 262
-- Name: SIUUP_EQUIPMENT_GENERAL_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIUUP_EQUIPMENT_GENERAL_id_seq"', 1, false);


--
-- TOC entry 3525 (class 0 OID 0)
-- Dependencies: 274
-- Name: SIUUP_EQUIPMENT_PROGRAM_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIUUP_EQUIPMENT_PROGRAM_id_seq"', 1, false);


--
-- TOC entry 3526 (class 0 OID 0)
-- Dependencies: 264
-- Name: SIUUP_LABORATORIES_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIUUP_LABORATORIES_id_seq"', 1, false);


--
-- TOC entry 3527 (class 0 OID 0)
-- Dependencies: 266
-- Name: SIUUP_PROGRAMS_CAT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIUUP_PROGRAMS_CAT_id_seq"', 1, false);


--
-- TOC entry 3528 (class 0 OID 0)
-- Dependencies: 268
-- Name: SIUUP_SCHEDULE_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIUUP_SCHEDULE_id_seq"', 1, false);


--
-- TOC entry 3529 (class 0 OID 0)
-- Dependencies: 270
-- Name: SIUUP_STATUS_EQUIPMENT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIUUP_STATUS_EQUIPMENT_id_seq"', 1, false);


--
-- TOC entry 3530 (class 0 OID 0)
-- Dependencies: 231
-- Name: SIUUP_STATUS_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIUUP_STATUS_id_seq"', 1, false);


--
-- TOC entry 3531 (class 0 OID 0)
-- Dependencies: 272
-- Name: SIUUP_TEACHER_PRACTICES_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SIUUP_TEACHER_PRACTICES_id_seq"', 1, false);


--
-- TOC entry 3532 (class 0 OID 0)
-- Dependencies: 202
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- TOC entry 3533 (class 0 OID 0)
-- Dependencies: 204
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- TOC entry 3534 (class 0 OID 0)
-- Dependencies: 200
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 152, true);


--
-- TOC entry 3535 (class 0 OID 0)
-- Dependencies: 208
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- TOC entry 3536 (class 0 OID 0)
-- Dependencies: 206
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- TOC entry 3537 (class 0 OID 0)
-- Dependencies: 210
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- TOC entry 3538 (class 0 OID 0)
-- Dependencies: 212
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- TOC entry 3539 (class 0 OID 0)
-- Dependencies: 198
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 38, true);


--
-- TOC entry 3540 (class 0 OID 0)
-- Dependencies: 196
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 22, true);


--
-- TOC entry 3054 (class 2606 OID 67936)
-- Name: SIIIP_ROLES_CAT SIIIP_ROLES_CAT_description_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIIP_ROLES_CAT"
    ADD CONSTRAINT "SIIIP_ROLES_CAT_description_key" UNIQUE (description);


--
-- TOC entry 3056 (class 2606 OID 67934)
-- Name: SIIIP_ROLES_CAT SIIIP_ROLES_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIIP_ROLES_CAT"
    ADD CONSTRAINT "SIIIP_ROLES_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3119 (class 2606 OID 68225)
-- Name: SIIUP_ALUMN_CAT SIIUP_ALUMN_CAT_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_ALUMN_CAT"
    ADD CONSTRAINT "SIIUP_ALUMN_CAT_email_key" UNIQUE (email);


--
-- TOC entry 3121 (class 2606 OID 68223)
-- Name: SIIUP_ALUMN_CAT SIIUP_ALUMN_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_ALUMN_CAT"
    ADD CONSTRAINT "SIIUP_ALUMN_CAT_pkey" PRIMARY KEY (enrollment);


--
-- TOC entry 3129 (class 2606 OID 68241)
-- Name: SIIUP_ALUMN_ESC_DET SIIUP_ALUMN_ESC_DET_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_ALUMN_ESC_DET"
    ADD CONSTRAINT "SIIUP_ALUMN_ESC_DET_pkey" PRIMARY KEY (id);


--
-- TOC entry 3008 (class 2606 OID 67876)
-- Name: SIIUP_CAREER_CAT SIIUP_CAREER_CAT_academic_program_name_gdp_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_CAT"
    ADD CONSTRAINT "SIIUP_CAREER_CAT_academic_program_name_gdp_key" UNIQUE (academic_program_name_gdp);


--
-- TOC entry 3010 (class 2606 OID 67872)
-- Name: SIIUP_CAREER_CAT SIIUP_CAREER_CAT_academic_program_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_CAT"
    ADD CONSTRAINT "SIIUP_CAREER_CAT_academic_program_name_key" UNIQUE (academic_program_name);


--
-- TOC entry 3013 (class 2606 OID 67874)
-- Name: SIIUP_CAREER_CAT SIIUP_CAREER_CAT_homosigla_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_CAT"
    ADD CONSTRAINT "SIIUP_CAREER_CAT_homosigla_key" UNIQUE (homosigla);


--
-- TOC entry 3016 (class 2606 OID 67870)
-- Name: SIIUP_CAREER_CAT SIIUP_CAREER_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_CAT"
    ADD CONSTRAINT "SIIUP_CAREER_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3115 (class 2606 OID 68081)
-- Name: SIIUP_CAREER_SUBJECT SIIUP_CAREER_SUBJECT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_SUBJECT"
    ADD CONSTRAINT "SIIUP_CAREER_SUBJECT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3020 (class 2606 OID 67886)
-- Name: SIIUP_CHARGE SIIUP_CHARGE_charge_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CHARGE"
    ADD CONSTRAINT "SIIUP_CHARGE_charge_key" UNIQUE (charge);


--
-- TOC entry 3023 (class 2606 OID 67888)
-- Name: SIIUP_CHARGE SIIUP_CHARGE_description_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CHARGE"
    ADD CONSTRAINT "SIIUP_CHARGE_description_key" UNIQUE (description);


--
-- TOC entry 3025 (class 2606 OID 67884)
-- Name: SIIUP_CHARGE SIIUP_CHARGE_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CHARGE"
    ADD CONSTRAINT "SIIUP_CHARGE_pkey" PRIMARY KEY (id);


--
-- TOC entry 3028 (class 2606 OID 67898)
-- Name: SIIUP_CYCLE_CAT SIIUP_CYCLE_CAT_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CYCLE_CAT"
    ADD CONSTRAINT "SIIUP_CYCLE_CAT_name_key" UNIQUE (name);


--
-- TOC entry 3030 (class 2606 OID 67896)
-- Name: SIIUP_CYCLE_CAT SIIUP_CYCLE_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CYCLE_CAT"
    ADD CONSTRAINT "SIIUP_CYCLE_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3034 (class 2606 OID 67908)
-- Name: SIIUP_GENERATION_CAT SIIUP_GENERATION_CAT_description_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GENERATION_CAT"
    ADD CONSTRAINT "SIIUP_GENERATION_CAT_description_key" UNIQUE (description);


--
-- TOC entry 3036 (class 2606 OID 67906)
-- Name: SIIUP_GENERATION_CAT SIIUP_GENERATION_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GENERATION_CAT"
    ADD CONSTRAINT "SIIUP_GENERATION_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3043 (class 2606 OID 67916)
-- Name: SIIUP_GROUP_CAT SIIUP_GROUP_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3111 (class 2606 OID 68038)
-- Name: SIIUP_GROUP_SUBJECT SIIUP_GROUP_SUBJECT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_SUBJECT"
    ADD CONSTRAINT "SIIUP_GROUP_SUBJECT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3105 (class 2606 OID 68030)
-- Name: SIIUP_GROUP_TYPE_CAT SIIUP_GROUP_TYPE_CAT_description_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_TYPE_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_TYPE_CAT_description_key" UNIQUE (description);


--
-- TOC entry 3107 (class 2606 OID 68028)
-- Name: SIIUP_GROUP_TYPE_CAT SIIUP_GROUP_TYPE_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_TYPE_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_TYPE_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3099 (class 2606 OID 68020)
-- Name: SIIUP_MODALITY_CAT SIIUP_MODALITY_CAT_description_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_MODALITY_CAT"
    ADD CONSTRAINT "SIIUP_MODALITY_CAT_description_key" UNIQUE (description);


--
-- TOC entry 3101 (class 2606 OID 68018)
-- Name: SIIUP_MODALITY_CAT SIIUP_MODALITY_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_MODALITY_CAT"
    ADD CONSTRAINT "SIIUP_MODALITY_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3095 (class 2606 OID 68010)
-- Name: SIIUP_PERIOD_CAT SIIUP_PERIOD_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_PERIOD_CAT"
    ADD CONSTRAINT "SIIUP_PERIOD_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3089 (class 2606 OID 68002)
-- Name: SIIUP_QUALIFICATION_TYPE_CAT SIIUP_QUALIFICATION_TYPE_CAT_description_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_QUALIFICATION_TYPE_CAT"
    ADD CONSTRAINT "SIIUP_QUALIFICATION_TYPE_CAT_description_key" UNIQUE (description);


--
-- TOC entry 3091 (class 2606 OID 68000)
-- Name: SIIUP_QUALIFICATION_TYPE_CAT SIIUP_QUALIFICATION_TYPE_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_QUALIFICATION_TYPE_CAT"
    ADD CONSTRAINT "SIIUP_QUALIFICATION_TYPE_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3049 (class 2606 OID 67926)
-- Name: SIIUP_QUARTER_CAT SIIUP_QUARTER_CAT_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_QUARTER_CAT"
    ADD CONSTRAINT "SIIUP_QUARTER_CAT_name_key" UNIQUE (name);


--
-- TOC entry 3051 (class 2606 OID 67924)
-- Name: SIIUP_QUARTER_CAT SIIUP_QUARTER_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_QUARTER_CAT"
    ADD CONSTRAINT "SIIUP_QUARTER_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3058 (class 2606 OID 67944)
-- Name: SIIUP_SHIFT_CAT SIIUP_SHIFT_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_SHIFT_CAT"
    ADD CONSTRAINT "SIIUP_SHIFT_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3069 (class 2606 OID 67964)
-- Name: SIIUP_STUDY_PLAN_CAT SIIUP_STUDY_PLAN_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_STUDY_PLAN_CAT"
    ADD CONSTRAINT "SIIUP_STUDY_PLAN_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3082 (class 2606 OID 67992)
-- Name: SIIUP_SUBJECT_CAT SIIUP_SUBJECT_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_SUBJECT_CAT"
    ADD CONSTRAINT "SIIUP_SUBJECT_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3134 (class 2606 OID 68288)
-- Name: SIIUP_TEACHER_CAT SIIUP_TEACHER_CAT_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TEACHER_CAT"
    ADD CONSTRAINT "SIIUP_TEACHER_CAT_email_key" UNIQUE (email);


--
-- TOC entry 3136 (class 2606 OID 68286)
-- Name: SIIUP_TEACHER_CAT SIIUP_TEACHER_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TEACHER_CAT"
    ADD CONSTRAINT "SIIUP_TEACHER_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3073 (class 2606 OID 67974)
-- Name: SIIUP_TRAINING_CYCLE_CAT SIIUP_TRAINING_CYCLE_CAT_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TRAINING_CYCLE_CAT"
    ADD CONSTRAINT "SIIUP_TRAINING_CYCLE_CAT_name_key" UNIQUE (name);


--
-- TOC entry 3075 (class 2606 OID 67972)
-- Name: SIIUP_TRAINING_CYCLE_CAT SIIUP_TRAINING_CYCLE_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TRAINING_CYCLE_CAT"
    ADD CONSTRAINT "SIIUP_TRAINING_CYCLE_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3123 (class 2606 OID 68233)
-- Name: SIIUP_TYPE_ALUMN SIIUP_TYPE_ALUMN_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TYPE_ALUMN"
    ADD CONSTRAINT "SIIUP_TYPE_ALUMN_pkey" PRIMARY KEY (id);


--
-- TOC entry 3078 (class 2606 OID 67984)
-- Name: SIIUP_TYPE_CAT SIIUP_TYPE_CAT_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TYPE_CAT"
    ADD CONSTRAINT "SIIUP_TYPE_CAT_name_key" UNIQUE (name);


--
-- TOC entry 3080 (class 2606 OID 67982)
-- Name: SIIUP_TYPE_CAT SIIUP_TYPE_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TYPE_CAT"
    ADD CONSTRAINT "SIIUP_TYPE_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3185 (class 2606 OID 68388)
-- Name: SIUUP_ALUM_PRATICES SIUUP_ALUM_PRATICES_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_ALUM_PRATICES"
    ADD CONSTRAINT "SIUUP_ALUM_PRATICES_pkey" PRIMARY KEY (id);


--
-- TOC entry 3140 (class 2606 OID 68305)
-- Name: SIUUP_CATEGORIES_EQUIPMENT SIUUP_CATEGORIES_EQUIPMENT_desciption_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_CATEGORIES_EQUIPMENT"
    ADD CONSTRAINT "SIUUP_CATEGORIES_EQUIPMENT_desciption_key" UNIQUE (desciption);


--
-- TOC entry 3142 (class 2606 OID 68303)
-- Name: SIUUP_CATEGORIES_EQUIPMENT SIUUP_CATEGORIES_EQUIPMENT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_CATEGORIES_EQUIPMENT"
    ADD CONSTRAINT "SIUUP_CATEGORIES_EQUIPMENT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3146 (class 2606 OID 68316)
-- Name: SIUUP_EQUIPMENT_GENERAL SIUUP_EQUIPMENT_GENERAL_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_EQUIPMENT_GENERAL"
    ADD CONSTRAINT "SIUUP_EQUIPMENT_GENERAL_pkey" PRIMARY KEY (id);


--
-- TOC entry 3179 (class 2606 OID 68370)
-- Name: SIUUP_EQUIPMENT_PROGRAM SIUUP_EQUIPMENT_PROGRAM_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_EQUIPMENT_PROGRAM"
    ADD CONSTRAINT "SIUUP_EQUIPMENT_PROGRAM_pkey" PRIMARY KEY (id);


--
-- TOC entry 3150 (class 2606 OID 68326)
-- Name: SIUUP_LABORATORIES SIUUP_LABORATORIES_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_LABORATORIES"
    ADD CONSTRAINT "SIUUP_LABORATORIES_name_key" UNIQUE (name);


--
-- TOC entry 3152 (class 2606 OID 68324)
-- Name: SIUUP_LABORATORIES SIUUP_LABORATORIES_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_LABORATORIES"
    ADD CONSTRAINT "SIUUP_LABORATORIES_pkey" PRIMARY KEY (id);


--
-- TOC entry 3155 (class 2606 OID 68336)
-- Name: SIUUP_PROGRAMS_CAT SIUUP_PROGRAMS_CAT_desciption_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_PROGRAMS_CAT"
    ADD CONSTRAINT "SIUUP_PROGRAMS_CAT_desciption_key" UNIQUE (desciption);


--
-- TOC entry 3157 (class 2606 OID 68334)
-- Name: SIUUP_PROGRAMS_CAT SIUUP_PROGRAMS_CAT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_PROGRAMS_CAT"
    ADD CONSTRAINT "SIUUP_PROGRAMS_CAT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3162 (class 2606 OID 68344)
-- Name: SIUUP_SCHEDULE SIUUP_SCHEDULE_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_SCHEDULE"
    ADD CONSTRAINT "SIUUP_SCHEDULE_pkey" PRIMARY KEY (id);


--
-- TOC entry 3168 (class 2606 OID 68354)
-- Name: SIUUP_STATUS_EQUIPMENT SIUUP_STATUS_EQUIPMENT_desciption_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_STATUS_EQUIPMENT"
    ADD CONSTRAINT "SIUUP_STATUS_EQUIPMENT_desciption_key" UNIQUE (desciption);


--
-- TOC entry 3170 (class 2606 OID 68352)
-- Name: SIUUP_STATUS_EQUIPMENT SIUUP_STATUS_EQUIPMENT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_STATUS_EQUIPMENT"
    ADD CONSTRAINT "SIUUP_STATUS_EQUIPMENT_pkey" PRIMARY KEY (id);


--
-- TOC entry 3061 (class 2606 OID 67956)
-- Name: SIUUP_STATUS SIUUP_STATUS_description_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_STATUS"
    ADD CONSTRAINT "SIUUP_STATUS_description_key" UNIQUE (description);


--
-- TOC entry 3063 (class 2606 OID 67952)
-- Name: SIUUP_STATUS SIUUP_STATUS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_STATUS"
    ADD CONSTRAINT "SIUUP_STATUS_pkey" PRIMARY KEY (id);


--
-- TOC entry 3066 (class 2606 OID 67954)
-- Name: SIUUP_STATUS SIUUP_STATUS_status_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_STATUS"
    ADD CONSTRAINT "SIUUP_STATUS_status_key" UNIQUE (status);


--
-- TOC entry 3174 (class 2606 OID 68362)
-- Name: SIUUP_TEACHER_PRACTICES SIUUP_TEACHER_PRACTICES_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_TEACHER_PRACTICES"
    ADD CONSTRAINT "SIUUP_TEACHER_PRACTICES_pkey" PRIMARY KEY (id);


--
-- TOC entry 2971 (class 2606 OID 67851)
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- TOC entry 2976 (class 2606 OID 67778)
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- TOC entry 2979 (class 2606 OID 67741)
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 2973 (class 2606 OID 67731)
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- TOC entry 2966 (class 2606 OID 67769)
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- TOC entry 2968 (class 2606 OID 67723)
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 2987 (class 2606 OID 67759)
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 2990 (class 2606 OID 67793)
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- TOC entry 2981 (class 2606 OID 67749)
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- TOC entry 2993 (class 2606 OID 67767)
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 2996 (class 2606 OID 67807)
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- TOC entry 2984 (class 2606 OID 67845)
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- TOC entry 2999 (class 2606 OID 67831)
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- TOC entry 2961 (class 2606 OID 67715)
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- TOC entry 2963 (class 2606 OID 67713)
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- TOC entry 2959 (class 2606 OID 67705)
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3003 (class 2606 OID 67860)
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- TOC entry 3052 (class 1259 OID 68112)
-- Name: SIIIP_ROLES_CAT_description_0cd08244_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIIP_ROLES_CAT_description_0cd08244_like" ON public."SIIIP_ROLES_CAT" USING btree (description varchar_pattern_ops);


--
-- TOC entry 3117 (class 1259 OID 68242)
-- Name: SIIUP_ALUMN_CAT_email_2da9cb18_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_ALUMN_CAT_email_2da9cb18_like" ON public."SIIUP_ALUMN_CAT" USING btree (email varchar_pattern_ops);


--
-- TOC entry 3124 (class 1259 OID 68273)
-- Name: SIIUP_ALUMN_ESC_DET_enrollment_id_ce21628b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_ALUMN_ESC_DET_enrollment_id_ce21628b" ON public."SIIUP_ALUMN_ESC_DET" USING btree (enrollment_id);


--
-- TOC entry 3125 (class 1259 OID 68274)
-- Name: SIIUP_ALUMN_ESC_DET_generation_id_9b5ae221; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_ALUMN_ESC_DET_generation_id_9b5ae221" ON public."SIIUP_ALUMN_ESC_DET" USING btree (generation_id);


--
-- TOC entry 3126 (class 1259 OID 68275)
-- Name: SIIUP_ALUMN_ESC_DET_group_id_2f6fd4c2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_ALUMN_ESC_DET_group_id_2f6fd4c2" ON public."SIIUP_ALUMN_ESC_DET" USING btree (group_id);


--
-- TOC entry 3127 (class 1259 OID 68276)
-- Name: SIIUP_ALUMN_ESC_DET_period_id_5d89f8cd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_ALUMN_ESC_DET_period_id_5d89f8cd" ON public."SIIUP_ALUMN_ESC_DET" USING btree (period_id);


--
-- TOC entry 3130 (class 1259 OID 68277)
-- Name: SIIUP_ALUMN_ESC_DET_postgraduate_id_859d41b0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_ALUMN_ESC_DET_postgraduate_id_859d41b0" ON public."SIIUP_ALUMN_ESC_DET" USING btree (postgraduate_id);


--
-- TOC entry 3131 (class 1259 OID 68278)
-- Name: SIIUP_ALUMN_ESC_DET_status_id_c2c29c9c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_ALUMN_ESC_DET_status_id_c2c29c9c" ON public."SIIUP_ALUMN_ESC_DET" USING btree (status_id);


--
-- TOC entry 3005 (class 1259 OID 68092)
-- Name: SIIUP_CAREER_CAT_academic_program_name_0018feb1_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CAREER_CAT_academic_program_name_0018feb1_like" ON public."SIIUP_CAREER_CAT" USING btree (academic_program_name varchar_pattern_ops);


--
-- TOC entry 3006 (class 1259 OID 68094)
-- Name: SIIUP_CAREER_CAT_academic_program_name_gdp_747f3ba3_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CAREER_CAT_academic_program_name_gdp_747f3ba3_like" ON public."SIIUP_CAREER_CAT" USING btree (academic_program_name_gdp varchar_pattern_ops);


--
-- TOC entry 3011 (class 1259 OID 68093)
-- Name: SIIUP_CAREER_CAT_homosigla_1af38af9_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CAREER_CAT_homosigla_1af38af9_like" ON public."SIIUP_CAREER_CAT" USING btree (homosigla varchar_pattern_ops);


--
-- TOC entry 3014 (class 1259 OID 68217)
-- Name: SIIUP_CAREER_CAT_modality_id_0a39ba0f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CAREER_CAT_modality_id_0a39ba0f" ON public."SIIUP_CAREER_CAT" USING btree (modality_id);


--
-- TOC entry 3017 (class 1259 OID 68218)
-- Name: SIIUP_CAREER_CAT_status_id_f96f3930; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CAREER_CAT_status_id_f96f3930" ON public."SIIUP_CAREER_CAT" USING btree (status_id);


--
-- TOC entry 3113 (class 1259 OID 68215)
-- Name: SIIUP_CAREER_SUBJECT_career_id_e1795af6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CAREER_SUBJECT_career_id_e1795af6" ON public."SIIUP_CAREER_SUBJECT" USING btree (career_id);


--
-- TOC entry 3116 (class 1259 OID 68216)
-- Name: SIIUP_CAREER_SUBJECT_subject_id_4fe1e459; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CAREER_SUBJECT_subject_id_4fe1e459" ON public."SIIUP_CAREER_SUBJECT" USING btree (subject_id);


--
-- TOC entry 3018 (class 1259 OID 68095)
-- Name: SIIUP_CHARGE_charge_4b038ed3_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CHARGE_charge_4b038ed3_like" ON public."SIIUP_CHARGE" USING btree (charge varchar_pattern_ops);


--
-- TOC entry 3021 (class 1259 OID 68096)
-- Name: SIIUP_CHARGE_description_83daa2c4_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CHARGE_description_83daa2c4_like" ON public."SIIUP_CHARGE" USING btree (description varchar_pattern_ops);


--
-- TOC entry 3026 (class 1259 OID 68097)
-- Name: SIIUP_CYCLE_CAT_name_3386e2b2_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CYCLE_CAT_name_3386e2b2_like" ON public."SIIUP_CYCLE_CAT" USING btree (name varchar_pattern_ops);


--
-- TOC entry 3031 (class 1259 OID 68204)
-- Name: SIIUP_CYCLE_CAT_status_id_46f571ce; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_CYCLE_CAT_status_id_46f571ce" ON public."SIIUP_CYCLE_CAT" USING btree (status_id);


--
-- TOC entry 3032 (class 1259 OID 68098)
-- Name: SIIUP_GENERATION_CAT_description_240822bf_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GENERATION_CAT_description_240822bf_like" ON public."SIIUP_GENERATION_CAT" USING btree (description varchar_pattern_ops);


--
-- TOC entry 3037 (class 1259 OID 68203)
-- Name: SIIUP_GENERATION_CAT_status_id_8fd35a3d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GENERATION_CAT_status_id_8fd35a3d" ON public."SIIUP_GENERATION_CAT" USING btree (status_id);


--
-- TOC entry 3038 (class 1259 OID 68109)
-- Name: SIIUP_GROUP_CAT_career_id_0dc07730; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_CAT_career_id_0dc07730" ON public."SIIUP_GROUP_CAT" USING btree (career_id);


--
-- TOC entry 3039 (class 1259 OID 68110)
-- Name: SIIUP_GROUP_CAT_generation_id_5ebb2736; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_CAT_generation_id_5ebb2736" ON public."SIIUP_GROUP_CAT" USING btree (generation_id);


--
-- TOC entry 3040 (class 1259 OID 68198)
-- Name: SIIUP_GROUP_CAT_group_type_id_824091aa; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_CAT_group_type_id_824091aa" ON public."SIIUP_GROUP_CAT" USING btree (group_type_id);


--
-- TOC entry 3041 (class 1259 OID 68199)
-- Name: SIIUP_GROUP_CAT_period_id_cdedacba; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_CAT_period_id_cdedacba" ON public."SIIUP_GROUP_CAT" USING btree (period_id);


--
-- TOC entry 3044 (class 1259 OID 68200)
-- Name: SIIUP_GROUP_CAT_quarter_id_62ab8649; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_CAT_quarter_id_62ab8649" ON public."SIIUP_GROUP_CAT" USING btree (quarter_id);


--
-- TOC entry 3045 (class 1259 OID 68201)
-- Name: SIIUP_GROUP_CAT_shift_id_58d39466; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_CAT_shift_id_58d39466" ON public."SIIUP_GROUP_CAT" USING btree (shift_id);


--
-- TOC entry 3046 (class 1259 OID 68202)
-- Name: SIIUP_GROUP_CAT_status_id_605142e2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_CAT_status_id_605142e2" ON public."SIIUP_GROUP_CAT" USING btree (status_id);


--
-- TOC entry 3109 (class 1259 OID 68196)
-- Name: SIIUP_GROUP_SUBJECT_group_id_145ee3e5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_SUBJECT_group_id_145ee3e5" ON public."SIIUP_GROUP_SUBJECT" USING btree (group_id);


--
-- TOC entry 3112 (class 1259 OID 68197)
-- Name: SIIUP_GROUP_SUBJECT_subject_id_0931a65d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_SUBJECT_subject_id_0931a65d" ON public."SIIUP_GROUP_SUBJECT" USING btree (subject_id);


--
-- TOC entry 3103 (class 1259 OID 68184)
-- Name: SIIUP_GROUP_TYPE_CAT_description_c533e01c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_TYPE_CAT_description_c533e01c_like" ON public."SIIUP_GROUP_TYPE_CAT" USING btree (description varchar_pattern_ops);


--
-- TOC entry 3108 (class 1259 OID 68185)
-- Name: SIIUP_GROUP_TYPE_CAT_status_id_668ee96f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_GROUP_TYPE_CAT_status_id_668ee96f" ON public."SIIUP_GROUP_TYPE_CAT" USING btree (status_id);


--
-- TOC entry 3097 (class 1259 OID 68177)
-- Name: SIIUP_MODALITY_CAT_description_5c46923b_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_MODALITY_CAT_description_5c46923b_like" ON public."SIIUP_MODALITY_CAT" USING btree (description varchar_pattern_ops);


--
-- TOC entry 3102 (class 1259 OID 68178)
-- Name: SIIUP_MODALITY_CAT_status_id_c6769341; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_MODALITY_CAT_status_id_c6769341" ON public."SIIUP_MODALITY_CAT" USING btree (status_id);


--
-- TOC entry 3093 (class 1259 OID 68170)
-- Name: SIIUP_PERIOD_CAT_cycle_id_ba79930f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_PERIOD_CAT_cycle_id_ba79930f" ON public."SIIUP_PERIOD_CAT" USING btree (cycle_id);


--
-- TOC entry 3096 (class 1259 OID 68171)
-- Name: SIIUP_PERIOD_CAT_status_id_2eb79177; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_PERIOD_CAT_status_id_2eb79177" ON public."SIIUP_PERIOD_CAT" USING btree (status_id);


--
-- TOC entry 3087 (class 1259 OID 68158)
-- Name: SIIUP_QUALIFICATION_TYPE_CAT_description_fd2f3f8c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_QUALIFICATION_TYPE_CAT_description_fd2f3f8c_like" ON public."SIIUP_QUALIFICATION_TYPE_CAT" USING btree (description varchar_pattern_ops);


--
-- TOC entry 3092 (class 1259 OID 68159)
-- Name: SIIUP_QUALIFICATION_TYPE_CAT_status_id_b9445425; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_QUALIFICATION_TYPE_CAT_status_id_b9445425" ON public."SIIUP_QUALIFICATION_TYPE_CAT" USING btree (status_id);


--
-- TOC entry 3047 (class 1259 OID 68111)
-- Name: SIIUP_QUARTER_CAT_name_433a006f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_QUARTER_CAT_name_433a006f_like" ON public."SIIUP_QUARTER_CAT" USING btree (name varchar_pattern_ops);


--
-- TOC entry 3067 (class 1259 OID 68125)
-- Name: SIIUP_STUDY_PLAN_CAT_career_id_acaa3242; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_STUDY_PLAN_CAT_career_id_acaa3242" ON public."SIIUP_STUDY_PLAN_CAT" USING btree (career_id);


--
-- TOC entry 3070 (class 1259 OID 68126)
-- Name: SIIUP_STUDY_PLAN_CAT_status_id_669b6e90; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_STUDY_PLAN_CAT_status_id_669b6e90" ON public."SIIUP_STUDY_PLAN_CAT" USING btree (status_id);


--
-- TOC entry 3083 (class 1259 OID 68149)
-- Name: SIIUP_SUBJECT_CAT_quarter_id_f47e038c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_SUBJECT_CAT_quarter_id_f47e038c" ON public."SIIUP_SUBJECT_CAT" USING btree (quarter_id);


--
-- TOC entry 3084 (class 1259 OID 68150)
-- Name: SIIUP_SUBJECT_CAT_status_id_8dc978d1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_SUBJECT_CAT_status_id_8dc978d1" ON public."SIIUP_SUBJECT_CAT" USING btree (status_id);


--
-- TOC entry 3085 (class 1259 OID 68151)
-- Name: SIIUP_SUBJECT_CAT_study_plan_id_fdd5c279; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_SUBJECT_CAT_study_plan_id_fdd5c279" ON public."SIIUP_SUBJECT_CAT" USING btree (study_plan_id);


--
-- TOC entry 3086 (class 1259 OID 68152)
-- Name: SIIUP_SUBJECT_CAT_training_cycle_id_2eecfa97; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_SUBJECT_CAT_training_cycle_id_2eecfa97" ON public."SIIUP_SUBJECT_CAT" USING btree (training_cycle_id);


--
-- TOC entry 3132 (class 1259 OID 68294)
-- Name: SIIUP_TEACHER_CAT_email_5f8edf5c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_TEACHER_CAT_email_5f8edf5c_like" ON public."SIIUP_TEACHER_CAT" USING btree (email varchar_pattern_ops);


--
-- TOC entry 3137 (class 1259 OID 68295)
-- Name: SIIUP_TEACHER_CAT_teacher_status_id_2f733f98; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_TEACHER_CAT_teacher_status_id_2f733f98" ON public."SIIUP_TEACHER_CAT" USING btree (teacher_status_id);


--
-- TOC entry 3071 (class 1259 OID 68127)
-- Name: SIIUP_TRAINING_CYCLE_CAT_name_bce8c941_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_TRAINING_CYCLE_CAT_name_bce8c941_like" ON public."SIIUP_TRAINING_CYCLE_CAT" USING btree (name varchar_pattern_ops);


--
-- TOC entry 3076 (class 1259 OID 68128)
-- Name: SIIUP_TYPE_CAT_name_f8269e1d_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIIUP_TYPE_CAT_name_f8269e1d_like" ON public."SIIUP_TYPE_CAT" USING btree (name varchar_pattern_ops);


--
-- TOC entry 3181 (class 1259 OID 68498)
-- Name: SIUUP_ALUM_PRATICES_enrollment_id_013d9f53; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_ALUM_PRATICES_enrollment_id_013d9f53" ON public."SIUUP_ALUM_PRATICES" USING btree (enrollment_id);


--
-- TOC entry 3182 (class 1259 OID 68499)
-- Name: SIUUP_ALUM_PRATICES_equipment_id_2cc92772; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_ALUM_PRATICES_equipment_id_2cc92772" ON public."SIUUP_ALUM_PRATICES" USING btree (equipment_id);


--
-- TOC entry 3183 (class 1259 OID 68500)
-- Name: SIUUP_ALUM_PRATICES_laboratory_id_9a89237d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_ALUM_PRATICES_laboratory_id_9a89237d" ON public."SIUUP_ALUM_PRATICES" USING btree (laboratory_id);


--
-- TOC entry 3186 (class 1259 OID 68501)
-- Name: SIUUP_ALUM_PRATICES_program_id_3a67132a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_ALUM_PRATICES_program_id_3a67132a" ON public."SIUUP_ALUM_PRATICES" USING btree (program_id);


--
-- TOC entry 3187 (class 1259 OID 68502)
-- Name: SIUUP_ALUM_PRATICES_schedule_id_1e191b37; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_ALUM_PRATICES_schedule_id_1e191b37" ON public."SIUUP_ALUM_PRATICES" USING btree (schedule_id);


--
-- TOC entry 3138 (class 1259 OID 68389)
-- Name: SIUUP_CATEGORIES_EQUIPMENT_desciption_b5c51399_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_CATEGORIES_EQUIPMENT_desciption_b5c51399_like" ON public."SIUUP_CATEGORIES_EQUIPMENT" USING btree (desciption varchar_pattern_ops);


--
-- TOC entry 3143 (class 1259 OID 68395)
-- Name: SIUUP_EQUIPMENT_GENERAL_category_id_2b69a292; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_EQUIPMENT_GENERAL_category_id_2b69a292" ON public."SIUUP_EQUIPMENT_GENERAL" USING btree (category_id);


--
-- TOC entry 3144 (class 1259 OID 68471)
-- Name: SIUUP_EQUIPMENT_GENERAL_laboratory_id_04797722; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_EQUIPMENT_GENERAL_laboratory_id_04797722" ON public."SIUUP_EQUIPMENT_GENERAL" USING btree (laboratory_id);


--
-- TOC entry 3147 (class 1259 OID 68472)
-- Name: SIUUP_EQUIPMENT_GENERAL_status_id_1a720619; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_EQUIPMENT_GENERAL_status_id_1a720619" ON public."SIUUP_EQUIPMENT_GENERAL" USING btree (status_id);


--
-- TOC entry 3177 (class 1259 OID 68469)
-- Name: SIUUP_EQUIPMENT_PROGRAM_equipment_id_78ea5dcc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_EQUIPMENT_PROGRAM_equipment_id_78ea5dcc" ON public."SIUUP_EQUIPMENT_PROGRAM" USING btree (equipment_id);


--
-- TOC entry 3180 (class 1259 OID 68470)
-- Name: SIUUP_EQUIPMENT_PROGRAM_prgram_id_898569a6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_EQUIPMENT_PROGRAM_prgram_id_898569a6" ON public."SIUUP_EQUIPMENT_PROGRAM" USING btree (prgram_id);


--
-- TOC entry 3148 (class 1259 OID 68396)
-- Name: SIUUP_LABORATORIES_name_4e733c99_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_LABORATORIES_name_4e733c99_like" ON public."SIUUP_LABORATORIES" USING btree (name varchar_pattern_ops);


--
-- TOC entry 3153 (class 1259 OID 68397)
-- Name: SIUUP_PROGRAMS_CAT_desciption_643f14b7_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_PROGRAMS_CAT_desciption_643f14b7_like" ON public."SIUUP_PROGRAMS_CAT" USING btree (desciption varchar_pattern_ops);


--
-- TOC entry 3158 (class 1259 OID 68428)
-- Name: SIUUP_SCHEDULE_Laboratory_id_ed36a840; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_SCHEDULE_Laboratory_id_ed36a840" ON public."SIUUP_SCHEDULE" USING btree ("Laboratory_id");


--
-- TOC entry 3159 (class 1259 OID 68429)
-- Name: SIUUP_SCHEDULE_group_id_2c573322; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_SCHEDULE_group_id_2c573322" ON public."SIUUP_SCHEDULE" USING btree (group_id);


--
-- TOC entry 3160 (class 1259 OID 68430)
-- Name: SIUUP_SCHEDULE_period_id_615165e4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_SCHEDULE_period_id_615165e4" ON public."SIUUP_SCHEDULE" USING btree (period_id);


--
-- TOC entry 3163 (class 1259 OID 68431)
-- Name: SIUUP_SCHEDULE_status_id_ca9f54d9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_SCHEDULE_status_id_ca9f54d9" ON public."SIUUP_SCHEDULE" USING btree (status_id);


--
-- TOC entry 3164 (class 1259 OID 68432)
-- Name: SIUUP_SCHEDULE_subject_id_14a0271b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_SCHEDULE_subject_id_14a0271b" ON public."SIUUP_SCHEDULE" USING btree (subject_id);


--
-- TOC entry 3165 (class 1259 OID 68433)
-- Name: SIUUP_SCHEDULE_teacher_id_14d752fe; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_SCHEDULE_teacher_id_14d752fe" ON public."SIUUP_SCHEDULE" USING btree (teacher_id);


--
-- TOC entry 3166 (class 1259 OID 68434)
-- Name: SIUUP_STATUS_EQUIPMENT_desciption_5d5e9a90_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_STATUS_EQUIPMENT_desciption_5d5e9a90_like" ON public."SIUUP_STATUS_EQUIPMENT" USING btree (desciption varchar_pattern_ops);


--
-- TOC entry 3059 (class 1259 OID 68114)
-- Name: SIUUP_STATUS_description_4be949fe_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_STATUS_description_4be949fe_like" ON public."SIUUP_STATUS" USING btree (description varchar_pattern_ops);


--
-- TOC entry 3064 (class 1259 OID 68113)
-- Name: SIUUP_STATUS_status_735db4b6_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_STATUS_status_735db4b6_like" ON public."SIUUP_STATUS" USING btree (status varchar_pattern_ops);


--
-- TOC entry 3171 (class 1259 OID 68455)
-- Name: SIUUP_TEACHER_PRACTICES_equipment_id_400c829d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_TEACHER_PRACTICES_equipment_id_400c829d" ON public."SIUUP_TEACHER_PRACTICES" USING btree (equipment_id);


--
-- TOC entry 3172 (class 1259 OID 68456)
-- Name: SIUUP_TEACHER_PRACTICES_laboratory_id_20067035; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_TEACHER_PRACTICES_laboratory_id_20067035" ON public."SIUUP_TEACHER_PRACTICES" USING btree (laboratory_id);


--
-- TOC entry 3175 (class 1259 OID 68457)
-- Name: SIUUP_TEACHER_PRACTICES_schedule_id_e7877ed0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_TEACHER_PRACTICES_schedule_id_e7877ed0" ON public."SIUUP_TEACHER_PRACTICES" USING btree (schedule_id);


--
-- TOC entry 3176 (class 1259 OID 68458)
-- Name: SIUUP_TEACHER_PRACTICES_teacher_id_3b30a282; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SIUUP_TEACHER_PRACTICES_teacher_id_3b30a282" ON public."SIUUP_TEACHER_PRACTICES" USING btree (teacher_id);


--
-- TOC entry 2969 (class 1259 OID 67852)
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- TOC entry 2974 (class 1259 OID 67789)
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- TOC entry 2977 (class 1259 OID 67790)
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- TOC entry 2964 (class 1259 OID 67775)
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- TOC entry 2985 (class 1259 OID 67805)
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- TOC entry 2988 (class 1259 OID 67804)
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- TOC entry 2991 (class 1259 OID 67819)
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- TOC entry 2994 (class 1259 OID 67818)
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- TOC entry 2982 (class 1259 OID 67846)
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- TOC entry 2997 (class 1259 OID 67842)
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- TOC entry 3000 (class 1259 OID 67843)
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- TOC entry 3001 (class 1259 OID 67862)
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- TOC entry 3004 (class 1259 OID 67861)
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- TOC entry 3223 (class 2606 OID 68243)
-- Name: SIIUP_ALUMN_ESC_DET SIIUP_ALUMN_ESC_DET_enrollment_id_ce21628b_fk_SIIUP_ALU; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_ALUMN_ESC_DET"
    ADD CONSTRAINT "SIIUP_ALUMN_ESC_DET_enrollment_id_ce21628b_fk_SIIUP_ALU" FOREIGN KEY (enrollment_id) REFERENCES public."SIIUP_ALUMN_CAT"(enrollment) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3224 (class 2606 OID 68248)
-- Name: SIIUP_ALUMN_ESC_DET SIIUP_ALUMN_ESC_DET_generation_id_9b5ae221_fk_SIIUP_GEN; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_ALUMN_ESC_DET"
    ADD CONSTRAINT "SIIUP_ALUMN_ESC_DET_generation_id_9b5ae221_fk_SIIUP_GEN" FOREIGN KEY (generation_id) REFERENCES public."SIIUP_GENERATION_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3225 (class 2606 OID 68253)
-- Name: SIIUP_ALUMN_ESC_DET SIIUP_ALUMN_ESC_DET_group_id_2f6fd4c2_fk_SIIUP_GROUP_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_ALUMN_ESC_DET"
    ADD CONSTRAINT "SIIUP_ALUMN_ESC_DET_group_id_2f6fd4c2_fk_SIIUP_GROUP_CAT_id" FOREIGN KEY (group_id) REFERENCES public."SIIUP_GROUP_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3226 (class 2606 OID 68258)
-- Name: SIIUP_ALUMN_ESC_DET SIIUP_ALUMN_ESC_DET_period_id_5d89f8cd_fk_SIIUP_PERIOD_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_ALUMN_ESC_DET"
    ADD CONSTRAINT "SIIUP_ALUMN_ESC_DET_period_id_5d89f8cd_fk_SIIUP_PERIOD_CAT_id" FOREIGN KEY (period_id) REFERENCES public."SIIUP_PERIOD_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3227 (class 2606 OID 68263)
-- Name: SIIUP_ALUMN_ESC_DET SIIUP_ALUMN_ESC_DET_postgraduate_id_859d41b0_fk_SIIUP_CAR; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_ALUMN_ESC_DET"
    ADD CONSTRAINT "SIIUP_ALUMN_ESC_DET_postgraduate_id_859d41b0_fk_SIIUP_CAR" FOREIGN KEY (postgraduate_id) REFERENCES public."SIIUP_CAREER_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3228 (class 2606 OID 68268)
-- Name: SIIUP_ALUMN_ESC_DET SIIUP_ALUMN_ESC_DET_status_id_c2c29c9c_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_ALUMN_ESC_DET"
    ADD CONSTRAINT "SIIUP_ALUMN_ESC_DET_status_id_c2c29c9c_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3197 (class 2606 OID 68082)
-- Name: SIIUP_CAREER_CAT SIIUP_CAREER_CAT_modality_id_0a39ba0f_fk_SIIUP_MODALITY_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_CAT"
    ADD CONSTRAINT "SIIUP_CAREER_CAT_modality_id_0a39ba0f_fk_SIIUP_MODALITY_CAT_id" FOREIGN KEY (modality_id) REFERENCES public."SIIUP_MODALITY_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3198 (class 2606 OID 68087)
-- Name: SIIUP_CAREER_CAT SIIUP_CAREER_CAT_status_id_f96f3930_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_CAT"
    ADD CONSTRAINT "SIIUP_CAREER_CAT_status_id_f96f3930_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3221 (class 2606 OID 68205)
-- Name: SIIUP_CAREER_SUBJECT SIIUP_CAREER_SUBJECT_career_id_e1795af6_fk_SIIUP_CAREER_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_SUBJECT"
    ADD CONSTRAINT "SIIUP_CAREER_SUBJECT_career_id_e1795af6_fk_SIIUP_CAREER_CAT_id" FOREIGN KEY (career_id) REFERENCES public."SIIUP_CAREER_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3222 (class 2606 OID 68210)
-- Name: SIIUP_CAREER_SUBJECT SIIUP_CAREER_SUBJECT_subject_id_4fe1e459_fk_SIIUP_SUB; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CAREER_SUBJECT"
    ADD CONSTRAINT "SIIUP_CAREER_SUBJECT_subject_id_4fe1e459_fk_SIIUP_SUB" FOREIGN KEY (subject_id) REFERENCES public."SIIUP_SUBJECT_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3199 (class 2606 OID 68069)
-- Name: SIIUP_CYCLE_CAT SIIUP_CYCLE_CAT_status_id_46f571ce_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_CYCLE_CAT"
    ADD CONSTRAINT "SIIUP_CYCLE_CAT_status_id_46f571ce_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3200 (class 2606 OID 68064)
-- Name: SIIUP_GENERATION_CAT SIIUP_GENERATION_CAT_status_id_8fd35a3d_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GENERATION_CAT"
    ADD CONSTRAINT "SIIUP_GENERATION_CAT_status_id_8fd35a3d_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3206 (class 2606 OID 68099)
-- Name: SIIUP_GROUP_CAT SIIUP_GROUP_CAT_career_id_0dc07730_fk_SIIUP_CAREER_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_CAT_career_id_0dc07730_fk_SIIUP_CAREER_CAT_id" FOREIGN KEY (career_id) REFERENCES public."SIIUP_CAREER_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3207 (class 2606 OID 68104)
-- Name: SIIUP_GROUP_CAT SIIUP_GROUP_CAT_generation_id_5ebb2736_fk_SIIUP_GEN; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_CAT_generation_id_5ebb2736_fk_SIIUP_GEN" FOREIGN KEY (generation_id) REFERENCES public."SIIUP_GENERATION_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3201 (class 2606 OID 68039)
-- Name: SIIUP_GROUP_CAT SIIUP_GROUP_CAT_group_type_id_824091aa_fk_SIIUP_GRO; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_CAT_group_type_id_824091aa_fk_SIIUP_GRO" FOREIGN KEY (group_type_id) REFERENCES public."SIIUP_GROUP_TYPE_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3202 (class 2606 OID 68044)
-- Name: SIIUP_GROUP_CAT SIIUP_GROUP_CAT_period_id_cdedacba_fk_SIIUP_PERIOD_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_CAT_period_id_cdedacba_fk_SIIUP_PERIOD_CAT_id" FOREIGN KEY (period_id) REFERENCES public."SIIUP_PERIOD_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3203 (class 2606 OID 68049)
-- Name: SIIUP_GROUP_CAT SIIUP_GROUP_CAT_quarter_id_62ab8649_fk_SIIUP_QUARTER_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_CAT_quarter_id_62ab8649_fk_SIIUP_QUARTER_CAT_id" FOREIGN KEY (quarter_id) REFERENCES public."SIIUP_QUARTER_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3204 (class 2606 OID 68054)
-- Name: SIIUP_GROUP_CAT SIIUP_GROUP_CAT_shift_id_58d39466_fk_SIIUP_SHIFT_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_CAT_shift_id_58d39466_fk_SIIUP_SHIFT_CAT_id" FOREIGN KEY (shift_id) REFERENCES public."SIIUP_SHIFT_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3205 (class 2606 OID 68059)
-- Name: SIIUP_GROUP_CAT SIIUP_GROUP_CAT_status_id_605142e2_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_CAT_status_id_605142e2_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3219 (class 2606 OID 68186)
-- Name: SIIUP_GROUP_SUBJECT SIIUP_GROUP_SUBJECT_group_id_145ee3e5_fk_SIIUP_GROUP_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_SUBJECT"
    ADD CONSTRAINT "SIIUP_GROUP_SUBJECT_group_id_145ee3e5_fk_SIIUP_GROUP_CAT_id" FOREIGN KEY (group_id) REFERENCES public."SIIUP_GROUP_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3220 (class 2606 OID 68191)
-- Name: SIIUP_GROUP_SUBJECT SIIUP_GROUP_SUBJECT_subject_id_0931a65d_fk_SIIUP_SUBJECT_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_SUBJECT"
    ADD CONSTRAINT "SIIUP_GROUP_SUBJECT_subject_id_0931a65d_fk_SIIUP_SUBJECT_CAT_id" FOREIGN KEY (subject_id) REFERENCES public."SIIUP_SUBJECT_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3218 (class 2606 OID 68179)
-- Name: SIIUP_GROUP_TYPE_CAT SIIUP_GROUP_TYPE_CAT_status_id_668ee96f_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_GROUP_TYPE_CAT"
    ADD CONSTRAINT "SIIUP_GROUP_TYPE_CAT_status_id_668ee96f_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3217 (class 2606 OID 68172)
-- Name: SIIUP_MODALITY_CAT SIIUP_MODALITY_CAT_status_id_c6769341_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_MODALITY_CAT"
    ADD CONSTRAINT "SIIUP_MODALITY_CAT_status_id_c6769341_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3215 (class 2606 OID 68160)
-- Name: SIIUP_PERIOD_CAT SIIUP_PERIOD_CAT_cycle_id_ba79930f_fk_SIIUP_CYCLE_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_PERIOD_CAT"
    ADD CONSTRAINT "SIIUP_PERIOD_CAT_cycle_id_ba79930f_fk_SIIUP_CYCLE_CAT_id" FOREIGN KEY (cycle_id) REFERENCES public."SIIUP_CYCLE_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3216 (class 2606 OID 68165)
-- Name: SIIUP_PERIOD_CAT SIIUP_PERIOD_CAT_status_id_2eb79177_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_PERIOD_CAT"
    ADD CONSTRAINT "SIIUP_PERIOD_CAT_status_id_2eb79177_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3214 (class 2606 OID 68153)
-- Name: SIIUP_QUALIFICATION_TYPE_CAT SIIUP_QUALIFICATION__status_id_b9445425_fk_SIUUP_STA; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_QUALIFICATION_TYPE_CAT"
    ADD CONSTRAINT "SIIUP_QUALIFICATION__status_id_b9445425_fk_SIUUP_STA" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3208 (class 2606 OID 68115)
-- Name: SIIUP_STUDY_PLAN_CAT SIIUP_STUDY_PLAN_CAT_career_id_acaa3242_fk_SIIUP_CAREER_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_STUDY_PLAN_CAT"
    ADD CONSTRAINT "SIIUP_STUDY_PLAN_CAT_career_id_acaa3242_fk_SIIUP_CAREER_CAT_id" FOREIGN KEY (career_id) REFERENCES public."SIIUP_CAREER_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3209 (class 2606 OID 68120)
-- Name: SIIUP_STUDY_PLAN_CAT SIIUP_STUDY_PLAN_CAT_status_id_669b6e90_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_STUDY_PLAN_CAT"
    ADD CONSTRAINT "SIIUP_STUDY_PLAN_CAT_status_id_669b6e90_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3210 (class 2606 OID 68129)
-- Name: SIIUP_SUBJECT_CAT SIIUP_SUBJECT_CAT_quarter_id_f47e038c_fk_SIIUP_QUARTER_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_SUBJECT_CAT"
    ADD CONSTRAINT "SIIUP_SUBJECT_CAT_quarter_id_f47e038c_fk_SIIUP_QUARTER_CAT_id" FOREIGN KEY (quarter_id) REFERENCES public."SIIUP_QUARTER_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3211 (class 2606 OID 68134)
-- Name: SIIUP_SUBJECT_CAT SIIUP_SUBJECT_CAT_status_id_8dc978d1_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_SUBJECT_CAT"
    ADD CONSTRAINT "SIIUP_SUBJECT_CAT_status_id_8dc978d1_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3212 (class 2606 OID 68139)
-- Name: SIIUP_SUBJECT_CAT SIIUP_SUBJECT_CAT_study_plan_id_fdd5c279_fk_SIIUP_STU; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_SUBJECT_CAT"
    ADD CONSTRAINT "SIIUP_SUBJECT_CAT_study_plan_id_fdd5c279_fk_SIIUP_STU" FOREIGN KEY (study_plan_id) REFERENCES public."SIIUP_STUDY_PLAN_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3213 (class 2606 OID 68144)
-- Name: SIIUP_SUBJECT_CAT SIIUP_SUBJECT_CAT_training_cycle_id_2eecfa97_fk_SIIUP_TRA; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_SUBJECT_CAT"
    ADD CONSTRAINT "SIIUP_SUBJECT_CAT_training_cycle_id_2eecfa97_fk_SIIUP_TRA" FOREIGN KEY (training_cycle_id) REFERENCES public."SIIUP_TRAINING_CYCLE_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3229 (class 2606 OID 68289)
-- Name: SIIUP_TEACHER_CAT SIIUP_TEACHER_CAT_teacher_status_id_2f733f98_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIIUP_TEACHER_CAT"
    ADD CONSTRAINT "SIIUP_TEACHER_CAT_teacher_status_id_2f733f98_fk_SIUUP_STATUS_id" FOREIGN KEY (teacher_status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3245 (class 2606 OID 68473)
-- Name: SIUUP_ALUM_PRATICES SIUUP_ALUM_PRATICES_enrollment_id_013d9f53_fk_SIIUP_ALU; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_ALUM_PRATICES"
    ADD CONSTRAINT "SIUUP_ALUM_PRATICES_enrollment_id_013d9f53_fk_SIIUP_ALU" FOREIGN KEY (enrollment_id) REFERENCES public."SIIUP_ALUMN_CAT"(enrollment) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3246 (class 2606 OID 68478)
-- Name: SIUUP_ALUM_PRATICES SIUUP_ALUM_PRATICES_equipment_id_2cc92772_fk_SIUUP_EQU; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_ALUM_PRATICES"
    ADD CONSTRAINT "SIUUP_ALUM_PRATICES_equipment_id_2cc92772_fk_SIUUP_EQU" FOREIGN KEY (equipment_id) REFERENCES public."SIUUP_EQUIPMENT_GENERAL"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3247 (class 2606 OID 68483)
-- Name: SIUUP_ALUM_PRATICES SIUUP_ALUM_PRATICES_laboratory_id_9a89237d_fk_SIUUP_LAB; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_ALUM_PRATICES"
    ADD CONSTRAINT "SIUUP_ALUM_PRATICES_laboratory_id_9a89237d_fk_SIUUP_LAB" FOREIGN KEY (laboratory_id) REFERENCES public."SIUUP_LABORATORIES"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3248 (class 2606 OID 68488)
-- Name: SIUUP_ALUM_PRATICES SIUUP_ALUM_PRATICES_program_id_3a67132a_fk_SIUUP_PRO; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_ALUM_PRATICES"
    ADD CONSTRAINT "SIUUP_ALUM_PRATICES_program_id_3a67132a_fk_SIUUP_PRO" FOREIGN KEY (program_id) REFERENCES public."SIUUP_PROGRAMS_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3249 (class 2606 OID 68493)
-- Name: SIUUP_ALUM_PRATICES SIUUP_ALUM_PRATICES_schedule_id_1e191b37_fk_SIUUP_SCHEDULE_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_ALUM_PRATICES"
    ADD CONSTRAINT "SIUUP_ALUM_PRATICES_schedule_id_1e191b37_fk_SIUUP_SCHEDULE_id" FOREIGN KEY (schedule_id) REFERENCES public."SIUUP_SCHEDULE"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3232 (class 2606 OID 68390)
-- Name: SIUUP_EQUIPMENT_GENERAL SIUUP_EQUIPMENT_GENE_category_id_2b69a292_fk_SIUUP_CAT; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_EQUIPMENT_GENERAL"
    ADD CONSTRAINT "SIUUP_EQUIPMENT_GENE_category_id_2b69a292_fk_SIUUP_CAT" FOREIGN KEY (category_id) REFERENCES public."SIUUP_CATEGORIES_EQUIPMENT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3230 (class 2606 OID 68371)
-- Name: SIUUP_EQUIPMENT_GENERAL SIUUP_EQUIPMENT_GENE_laboratory_id_04797722_fk_SIUUP_LAB; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_EQUIPMENT_GENERAL"
    ADD CONSTRAINT "SIUUP_EQUIPMENT_GENE_laboratory_id_04797722_fk_SIUUP_LAB" FOREIGN KEY (laboratory_id) REFERENCES public."SIUUP_LABORATORIES"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3231 (class 2606 OID 68376)
-- Name: SIUUP_EQUIPMENT_GENERAL SIUUP_EQUIPMENT_GENE_status_id_1a720619_fk_SIUUP_STA; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_EQUIPMENT_GENERAL"
    ADD CONSTRAINT "SIUUP_EQUIPMENT_GENE_status_id_1a720619_fk_SIUUP_STA" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS_EQUIPMENT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3243 (class 2606 OID 68459)
-- Name: SIUUP_EQUIPMENT_PROGRAM SIUUP_EQUIPMENT_PROG_equipment_id_78ea5dcc_fk_SIUUP_EQU; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_EQUIPMENT_PROGRAM"
    ADD CONSTRAINT "SIUUP_EQUIPMENT_PROG_equipment_id_78ea5dcc_fk_SIUUP_EQU" FOREIGN KEY (equipment_id) REFERENCES public."SIUUP_EQUIPMENT_GENERAL"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3244 (class 2606 OID 68464)
-- Name: SIUUP_EQUIPMENT_PROGRAM SIUUP_EQUIPMENT_PROG_prgram_id_898569a6_fk_SIUUP_PRO; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_EQUIPMENT_PROGRAM"
    ADD CONSTRAINT "SIUUP_EQUIPMENT_PROG_prgram_id_898569a6_fk_SIUUP_PRO" FOREIGN KEY (prgram_id) REFERENCES public."SIUUP_PROGRAMS_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3233 (class 2606 OID 68398)
-- Name: SIUUP_SCHEDULE SIUUP_SCHEDULE_Laboratory_id_ed36a840_fk_SIUUP_LABORATORIES_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_SCHEDULE"
    ADD CONSTRAINT "SIUUP_SCHEDULE_Laboratory_id_ed36a840_fk_SIUUP_LABORATORIES_id" FOREIGN KEY ("Laboratory_id") REFERENCES public."SIUUP_LABORATORIES"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3234 (class 2606 OID 68403)
-- Name: SIUUP_SCHEDULE SIUUP_SCHEDULE_group_id_2c573322_fk_SIIUP_GROUP_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_SCHEDULE"
    ADD CONSTRAINT "SIUUP_SCHEDULE_group_id_2c573322_fk_SIIUP_GROUP_CAT_id" FOREIGN KEY (group_id) REFERENCES public."SIIUP_GROUP_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3235 (class 2606 OID 68408)
-- Name: SIUUP_SCHEDULE SIUUP_SCHEDULE_period_id_615165e4_fk_SIIUP_PERIOD_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_SCHEDULE"
    ADD CONSTRAINT "SIUUP_SCHEDULE_period_id_615165e4_fk_SIIUP_PERIOD_CAT_id" FOREIGN KEY (period_id) REFERENCES public."SIIUP_PERIOD_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3236 (class 2606 OID 68413)
-- Name: SIUUP_SCHEDULE SIUUP_SCHEDULE_status_id_ca9f54d9_fk_SIUUP_STATUS_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_SCHEDULE"
    ADD CONSTRAINT "SIUUP_SCHEDULE_status_id_ca9f54d9_fk_SIUUP_STATUS_id" FOREIGN KEY (status_id) REFERENCES public."SIUUP_STATUS"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3237 (class 2606 OID 68418)
-- Name: SIUUP_SCHEDULE SIUUP_SCHEDULE_subject_id_14a0271b_fk_SIIUP_SUBJECT_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_SCHEDULE"
    ADD CONSTRAINT "SIUUP_SCHEDULE_subject_id_14a0271b_fk_SIIUP_SUBJECT_CAT_id" FOREIGN KEY (subject_id) REFERENCES public."SIIUP_SUBJECT_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3238 (class 2606 OID 68423)
-- Name: SIUUP_SCHEDULE SIUUP_SCHEDULE_teacher_id_14d752fe_fk_SIIUP_TEACHER_CAT_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_SCHEDULE"
    ADD CONSTRAINT "SIUUP_SCHEDULE_teacher_id_14d752fe_fk_SIIUP_TEACHER_CAT_id" FOREIGN KEY (teacher_id) REFERENCES public."SIIUP_TEACHER_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3239 (class 2606 OID 68435)
-- Name: SIUUP_TEACHER_PRACTICES SIUUP_TEACHER_PRACTI_equipment_id_400c829d_fk_SIUUP_EQU; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_TEACHER_PRACTICES"
    ADD CONSTRAINT "SIUUP_TEACHER_PRACTI_equipment_id_400c829d_fk_SIUUP_EQU" FOREIGN KEY (equipment_id) REFERENCES public."SIUUP_EQUIPMENT_GENERAL"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3240 (class 2606 OID 68440)
-- Name: SIUUP_TEACHER_PRACTICES SIUUP_TEACHER_PRACTI_laboratory_id_20067035_fk_SIUUP_LAB; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_TEACHER_PRACTICES"
    ADD CONSTRAINT "SIUUP_TEACHER_PRACTI_laboratory_id_20067035_fk_SIUUP_LAB" FOREIGN KEY (laboratory_id) REFERENCES public."SIUUP_LABORATORIES"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3241 (class 2606 OID 68445)
-- Name: SIUUP_TEACHER_PRACTICES SIUUP_TEACHER_PRACTI_schedule_id_e7877ed0_fk_SIUUP_SCH; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_TEACHER_PRACTICES"
    ADD CONSTRAINT "SIUUP_TEACHER_PRACTI_schedule_id_e7877ed0_fk_SIUUP_SCH" FOREIGN KEY (schedule_id) REFERENCES public."SIUUP_SCHEDULE"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3242 (class 2606 OID 68450)
-- Name: SIUUP_TEACHER_PRACTICES SIUUP_TEACHER_PRACTI_teacher_id_3b30a282_fk_SIIUP_TEA; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SIUUP_TEACHER_PRACTICES"
    ADD CONSTRAINT "SIUUP_TEACHER_PRACTI_teacher_id_3b30a282_fk_SIIUP_TEA" FOREIGN KEY (teacher_id) REFERENCES public."SIIUP_TEACHER_CAT"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3190 (class 2606 OID 67784)
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3189 (class 2606 OID 67779)
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3188 (class 2606 OID 67770)
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3192 (class 2606 OID 67799)
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3191 (class 2606 OID 67794)
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3194 (class 2606 OID 67813)
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3193 (class 2606 OID 67808)
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3195 (class 2606 OID 67832)
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3196 (class 2606 OID 67837)
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


-- Completed on 2022-05-27 12:56:54

--
-- PostgreSQL database dump complete
--


INSERT INTO public."SIUUP_PROGRAMS_CAT"(id, desciption, version) VALUES 
    (1 , '123D Design R2.2', '2.2.12'),
    (2 , 'Acronis True Image', '23.5.17750'),
    (3 , 'Adobe Acrobat Reader DC', '20-006-20034'),
    (4 , 'Adobe after Effects', '2020'),
    (5 , 'Adobe illustrator CC', '2019'),
    (6 , 'Allegorithamic Substance Painter', '2018'),
    (7 , 'AOMEI Partition Assistant', '8.10'),
    (8 , 'Autodesk 3ds Max', '2020'),
    (9 , 'Autodesk App Manager', '2020'),
    (10, 'Autodesk AutoCAD', '2020 '),
    (11, 'Autodesk Certificate Package', '7.1.4.0'),
    (12, 'Autodesk Civil View for 3ds Max', '2020'),
    (13, 'Autodesk Configurator 360 addin', '24.0.10100'),
    (14, 'Autodesk Desktop Connect Service', '5.02.0'),
    (15, 'Autodesk Download Manager', '6.1.32.0'),
    (16, 'Autodesk DWG TrueView', '2020'),
    (17, 'Autodesk Genuine Service', '3.0.11'),
    (18, 'Autodesk Genuine Service', '2.2.0'),
    (19, 'Autodesk Guided Tutorial Plugin', '7.02.0'),
    (20, 'Autodesk inventor', '2020'),
    (21, 'Autodesk Inventor Content Center Libraries', '2020 '),
    (22, 'Autodesk Inventor Electrical Catalog Browser', '2020 '),
    (23, 'Autodesk Inventor Server Engine for 3ds Max', '2020 '),
    (24, 'Autodesk License Service', '7.1.4.0'),
    (25, 'Autodesk Material Librery', '2020'),
    (26, 'Autodesk Maya', '2019'),
    (27, 'Autodesk Revit Interoperability for 3ds Max', '2020 '),
    (28, 'Autodesk Revit Interoperability for inventor', '2020 '),
    (29, 'Autodesk Single Sing On Component', '20.0.0364'),
    (30, 'Avira Security', '0.0.0.0'),
    (31, 'Bifrost', '2019'),
    (32, 'Blender', '2.80.0'),
    (33, 'Bonjour', '3.0.0.10'),
    (34, 'DaVinci Resolve', '16.1.1005'),
    (35, 'DaVinci Resolve Keyboards', '1.0.0.0'),
    (36, 'DaVinci Resolve Panels', '1.3.1.0'),
    (37, 'Dia', '0.0.0.0'),
    (38, 'GIMP', '2.10.2'),
    (39, 'Glass Fish Server Open Source', '4.1.1'),
    (40, 'Google Chrome', '98.0.4758.102'),
    (41, 'Guía interactiva EXANI', '1.1.0'),
    (42, 'Inkscape', '0.92.4'),
    (43, 'Java', '8'),
    (44, 'Java SE Development Kit', '8'),
    (45, 'Krita', '4.2.5'),
    (46, 'LibreOffice', '6.1.5.2'),
    (47, 'LightZone', '4.1.7'),
    (48, 'Maxon Cinema 4Da R21', 'R21'),
    (49, 'MAXtoA for 3ds Max', '2020'),
    (50, 'Microsoft Access database engine', '2010'),
    (51, 'Microsoft ODBC Driver', '11'),
    (52, 'Microsoft Office Web Components' , '2003'),
    (53, 'Microsoft One Drive', '21.220.1024.0005'),
    (54, 'Microsoft SQL Server', '2008' ),
    (55, 'Microsoft SQL Server', '2012' ),
    (56, 'Microsoft SQL Server' , '2014'),
    (57, 'Microsoft Visual C++', '2005'),
    (58, 'Microsoft Visual C++', '2008'),
    (59, 'Microsoft Visual C++', '2010'),
    (60, 'Microsoft Visual C++', '2012'),
    (61, 'Microsoft Visual C++', '2013'),
    (62, 'Microsoft Visual C++', '2017'),
    (63, 'MtoA for Maya ', '2019'),
    (64, 'MySQL Workbench' , '8.0'),
    (65, 'NetBeans IDE', '8.2'),
    (66, 'Notepad++', '7.7.1'),
    (67, 'Nuke', '11.3v5'),
    (68, 'Opera Stable', '84.04316.21'),
    (69, 'Oracle VM VirtualBox', '6.0.10'),
    (70, 'PDFCreator', '2.1.2'),
    (71, 'SOLIDWORKS' , '2016'),
    (72, 'SQL Server Browser' , '2014' ),
    (73, 'Sublime Text', '3'),
    (74, 'Substance in Maya' , '2019'),
    (75, 'Tablet Wacom', '6.3.32-4'),
    (76, 'TeamViewer' , '14'),
    (77, 'Udeler', '1.8.0'),
    (78, 'UltraISO Premium', '9.12'),
    (79, 'Unity', '2019.2.4f1'),
    (80, 'Unity Hub', '2.1.1'),
    (81, 'Wampserver', '3.1.9'),
    (82, 'WinRAR', '5.70.0');



INSERT INTO public."SIIUP_TEACHER_CAT"(first_name, last_name, second_last_name, email, gender, teacher_status_id) VALUES 
    ('Carolina', 'Barrios', 'Molina', 'carolina.barrios@uptapachula.edu.mx', 'F', 2),
    ('Ceila Merari', 'Gonzáles', 'Hernádez', 'ceila.gonzáles@uptapachula.edu.mx', 'F', 2),
    ('Cristóbal', 'Guzmán', 'Paz', 'cristobal.guzman@uptapachula.edu.mx', 'M', 2),
    ('Fernando', 'Cossio', 'Esquivel', 'fernando.cossio@uptapachula.edu.mx', 'M', 2),
    ('Gerardo Raul', 'Balderas', 'Gamboa', 'gerardo.balderas@uptapachula.edu.mx', 'M', 2),
    ('Jose Eduardo', 'Pacheco', 'Flores', 'jose.pacheco@uptapachula.edu.mx', 'M', 2),
    ('Pedro de Jesus', 'Girón', 'Cigarroa', 'pedro.giron@uptapachula.edu.mx', 'M', 2),
    ('Trinidad', 'López', 'Méndez', 'trinidad.mendez@uptapachula.edu.mx', 'M', 2);