from django.apps import AppConfig


class LaboratoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.laboratory'
    verbose_name = 'Laboratorios'
    icon_name = 'person'
