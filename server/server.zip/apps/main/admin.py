from django.contrib.admin import ModelAdmin
from django.contrib import admin

from apps.main.models import *

@admin.register(StatusModel)
class StatusAdmin(ModelAdmin):
   list_display = ('id', 'description')

@admin.register(CycleModel)
class CycleAdmin(ModelAdmin):
   list_display = ('id', 'name', 'start_date', 'end_date', 'status')
   list_filter = ('status',)
   list_display_links = ('name',)
   actions = None

@admin.register(CareerModel)
class CareerAdmin(ModelAdmin):
   list_display = ('id', 'academic_program_name', 'homosigla', 'status', 'modality')
   search_fields = ('academic_program_name', 'homosigla',)
   list_filter = ('status', 'modality',)
   actions = None
   ordering = ('id',)
   list_display_links = ('academic_program_name',)
   # list_editable = ()
   # list_per_page = ()
   # exclude = ()
    

@admin.register(ModalityModel)
class ModalityAdmin(ModelAdmin):
   list_display = ('id', 'description', 'status')
   list_display_links = ('description',)
   list_filter = ('status',)
   actions = None

@admin.register(QuarterModel)
class QuarterModel(ModelAdmin):
   actions = None

@admin.register(SubjectModel)
class SubjectAdmin(ModelAdmin):
   list_display = ('id', 'name', 'quarter', 'status')
   search_fields = ('name',)
   list_filter = ('status', 'quarter',)
   actions = None
   ordering = ('name',)
   list_display_links = ('name',)
   ist_per_page = 50

admin.site.register(PeriodModel)
admin.site.register(ShiftModel)
admin.site.register(GroupModel)


admin.site.site_header = 'Laboratorios UpTap'
admin.site.site_title = 'UpTap'
admin.site.index_title = 'Laboratorios'