from django.contrib.admin import site, ModelAdmin
from .models import TeacherModel

class TeacherAdmin(ModelAdmin):
   list_display = ('id', '__str__', 'gender', 'email', 'teacher_status',)
   list_filter = ('teacher_status', 'gender')
   list_display_links = ('__str__',)

site.register(TeacherModel, TeacherAdmin)

