from django.contrib.admin import site, ModelAdmin
from apps.alumn.models import AlumnModel

class AlumAdmin(ModelAdmin):
   list_display = ('enrollment', '__str__', 'gender', 'email')
   list_filter = ('gender',)

site.register(AlumnModel, AlumAdmin)
